import { 
  PhishingTemplate, 
  PhishingCampaign, 
  MicrolearningCourse, 
  ComplianceFramework, 
  EmployeeRecord, 
  SimulationEvent 
} from '../types';

export const INITIAL_PHISHING_TEMPLATES: PhishingTemplate[] = [
  {
    id: 'tmpl-m365-session',
    name: 'Microsoft 365: Urgent Password & Session Expiry',
    attackVector: 'Credential Harvesting',
    difficulty: 3,
    senderName: 'Microsoft Security Team',
    senderEmail: 'account-security@m1crosoft-online-notice.com',
    displayDomain: 'm1crosoft-online-notice.com',
    realDomain: 'm1crosoft-online-notice.com',
    replyTo: 'bounce-daemon@external-mailer-relay.net',
    subject: 'CRITICAL: Your Microsoft 365 access credentials expire in 2 hours',
    preheader: 'Your single sign-on authentication key requires immediate renewal.',
    dateSent: 'Today at 09:14 AM',
    displayLinkText: 'Keep Current Password & Renew Session',
    simulatedLinkUrl: 'https://login-auth.m1crosoft-online-notice.com/auth/sso/renew?user=victim',
    landingPageType: 'microsoft_login',
    explanationSummary: 'Uses artificial urgency ("2 hours") and an optical typosquatting domain (m1crosoft with a numeral 1) to trick employees into surrendering SSO credentials.',
    historicalClickRate: 18.7,
    htmlContent: `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; color: #1e293b; line-height: 1.5;">
        <div style="padding-bottom: 16px; border-bottom: 2px solid #0078d4;">
          <span style="font-size: 20px; font-weight: 700; color: #0078d4; letter-spacing: -0.5px;">Microsoft</span>
          <span style="font-size: 14px; color: #64748b; margin-left: 8px;">Security & Account Protection</span>
        </div>
        
        <div style="padding: 24px 0;">
          <h2 style="font-size: 18px; font-weight: 600; color: #0f172a; margin-top: 0;">Session Expiration Notice</h2>
          <p style="font-size: 14px; color: #334155;">Hello Team Member,</p>
          <p style="font-size: 14px; color: #334155;">
            Our automated security token monitor detected that your enterprise single sign-on credential token is scheduled to expire in <strong>2 hours (11:15 AM EST)</strong>.
          </p>
          <p style="font-size: 14px; color: #334155;">
            To avoid disruption to Outlook, Teams, and OneDrive services during working hours, please verify your identity and retain your existing credentials below.
          </p>
          
          <div style="margin: 28px 0; text-align: left;">
            <a href="#simulate-click" style="background-color: #0078d4; color: #ffffff; padding: 12px 24px; text-decoration: none; font-size: 14px; font-weight: 600; border-radius: 4px; display: inline-block;">
              Keep Current Password & Renew Session
            </a>
          </div>

          <div style="background-color: #f8fafc; border-left: 4px solid #f59e0b; padding: 12px 16px; font-size: 12px; color: #64748b; margin-top: 24px;">
            <strong>Security Notice:</strong> Failure to renew before the deadline will require manual IT Helpdesk re-provisioning and direct supervisor approval.
          </div>
        </div>

        <div style="border-top: 1px solid #e2e8f0; padding-top: 16px; font-size: 11px; color: #94a3b8;">
          <p>Microsoft Corporation, One Microsoft Way, Redmond, WA 98052 | Security Ref: MS-SEC-89211-US</p>
        </div>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-1',
        location: 'sender',
        title: 'Typosquatted Lookalike Domain',
        description: 'The sender domain contains "m1crosoft" with the number "1" instead of the letter "i". Legit Microsoft emails originate strictly from @microsoft.com or @accountprotection.microsoft.com.',
        severity: 'critical'
      },
      {
        id: 'rf-2',
        location: 'subject',
        title: 'Manufactured Urgency',
        description: 'Attackers create panic with artificial deadlines ("expires in 2 hours") to bypass critical reasoning and stop you from verifying with IT.',
        severity: 'high'
      },
      {
        id: 'rf-3',
        location: 'replyTo',
        title: 'Hidden External Relay Address',
        description: 'The hidden Reply-To header points to external-mailer-relay.net instead of Microsoft servers.',
        severity: 'critical'
      },
      {
        id: 'rf-4',
        location: 'link',
        title: 'Suspicious Target URL',
        description: 'Hovering over the button reveals "login-auth.m1crosoft-online-notice.com" rather than the corporate portal login.microsoftonline.com.',
        severity: 'critical'
      }
    ]
  },
  {
    id: 'tmpl-bec-wire',
    name: 'Executive Wire Transfer Request (CEO Fraud)',
    attackVector: 'Business Email Compromise (BEC)',
    difficulty: 4,
    senderName: 'David Sterling (Chief Executive Officer)',
    senderEmail: 'david.sterling@acme-corp.exec-mail-desk.com',
    displayDomain: 'acme-corp.exec-mail-desk.com',
    realDomain: 'acme-corp.exec-mail-desk.com',
    replyTo: 'd.sterling.private.mobile@gmail.com',
    subject: 'Urgent: Confidential Vendor Settlement before 12:00 PM',
    preheader: 'Please process this urgent acquisition payment immediately; I am in back-to-back board meetings.',
    dateSent: 'Today at 08:42 AM',
    displayLinkText: 'View Escrow Account Wire Details (Encrypted PDF)',
    simulatedLinkUrl: 'https://secure-doc-share.acme-corp.exec-mail-desk.com/wire/transact/89127',
    landingPageType: 'payroll_direct_deposit',
    explanationSummary: 'A high-stakes CEO impersonation email attempting to induce finance staff to bypass dual-authorization wire approval procedures under the guise of an executive emergency.',
    historicalClickRate: 14.2,
    htmlContent: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; color: #1e293b; line-height: 1.6;">
        <p style="font-size: 14px; margin-top: 0;">Good morning,</p>
        <p style="font-size: 14px;">
          I am currently in back-to-back closed board sessions all morning regarding the Q3 international supplier acquisition. 
        </p>
        <p style="font-size: 14px;">
          Our lead counsel confirmed we need to wire the closing settlement balance of <strong>$48,750.00</strong> to the escrow trust before noon today to satisfy closing conditions.
        </p>
        <p style="font-size: 14px;">
          Please process this via domestic Fedwire immediately. Since I cannot take calls during the executive hearing, review the instructions attached or linked below and confirm once queued:
        </p>
        
        <div style="margin: 20px 0;">
          <a href="#simulate-click" style="color: #2563eb; font-weight: 600; text-decoration: underline; font-size: 14px;">
            View Escrow Account Wire Details (Encrypted PDF)
          </a>
        </div>

        <p style="font-size: 14px;">
          Keep this strictly between us until the formal press announcement tomorrow. Let me know as soon as the reference number is generated.
        </p>
        
        <p style="font-size: 13px; color: #475569; margin-top: 24px;">
          Best regards,<br/>
          <strong>David Sterling</strong><br/>
          Chief Executive Officer<br/>
          <span style="font-size: 11px; color: #94a3b8;">Sent from my executive iPad device</span>
        </p>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-bec-1',
        location: 'sender',
        title: 'Executive Spoofing Domain',
        description: 'The email comes from "acme-corp.exec-mail-desk.com", an external lookalike domain not associated with the official corporate domain.',
        severity: 'critical'
      },
      {
        id: 'rf-bec-2',
        location: 'replyTo',
        title: 'Personal Gmail in Reply-To Header',
        description: 'Replies are quietly rerouted to "d.sterling.private.mobile@gmail.com", completely bypassing the corporate email security filters.',
        severity: 'critical'
      },
      {
        id: 'rf-bec-3',
        location: 'body',
        title: 'Pretexting Isolation & Pressure to Bypass Controls',
        description: 'Claims the executive is "in closed board meetings" and cannot take calls—a classic BEC tactic designed to discourage secondary verification by phone.',
        severity: 'critical'
      }
    ]
  },
  {
    id: 'tmpl-docusign-po',
    name: 'DocuSign: Electronic Signature Requested on Vendor MSA',
    attackVector: 'Credential Harvesting',
    difficulty: 2,
    senderName: 'DocuSign System Notification',
    senderEmail: 'service@docus1gn-esignature-hub.net',
    displayDomain: 'docus1gn-esignature-hub.net',
    realDomain: 'docus1gn-esignature-hub.net',
    subject: 'Please DocuSign: Master Services Agreement Amendment #2026-901',
    preheader: 'Finance Operations has sent you a document to review and sign.',
    dateSent: 'Yesterday at 04:30 PM',
    displayLinkText: 'Review and Sign Document',
    simulatedLinkUrl: 'https://auth-portal.docus1gn-esignature-hub.net/v2/envelope/sign',
    landingPageType: 'docusign_portal',
    explanationSummary: 'A copycat electronic signature notification mimicking standard vendor approval workflows, prompting victims to enter corporate credentials to view the document.',
    historicalClickRate: 24.1,
    htmlContent: `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0;">
        <div style="background-color: #005cb9; padding: 18px 24px; text-align: left;">
          <span style="color: #ffffff; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">DocuSign</span>
        </div>
        
        <div style="padding: 24px;">
          <div style="display: flex; align-items: center; margin-bottom: 20px;">
            <div style="font-size: 15px; color: #1e293b;">
              <strong>Global Enterprise Legal</strong> sent you a document for review and signature.
            </div>
          </div>
          
          <div style="background-color: #f1f5f9; border-radius: 6px; padding: 16px; margin-bottom: 24px;">
            <div style="font-size: 13px; font-weight: 600; color: #334155;">Master Services Agreement Amendment #2026-901.pdf</div>
            <div style="font-size: 12px; color: #64748b; margin-top: 4px;">Expires: In 3 calendar days · Envelope ID: E89A-0012-78B</div>
          </div>

          <div style="text-align: center; margin: 28px 0;">
            <a href="#simulate-click" style="background-color: #ffc820; color: #1e293b; padding: 14px 36px; text-decoration: none; font-size: 15px; font-weight: 700; border-radius: 4px; display: inline-block;">
              Review and Sign Document
            </a>
          </div>

          <p style="font-size: 12px; color: #64748b; line-height: 1.5;">
            Do not share this email. This link is unique to you and provides direct access to legal binding terms.
          </p>
        </div>

        <div style="background-color: #f8fafc; padding: 16px 24px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0;">
          This message was generated by DocuSign eSignature Engine on behalf of Global Enterprise Operations.
        </div>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-doc-1',
        location: 'sender',
        title: 'Fake DocuSign Domain',
        description: 'Notice "docus1gn-esignature-hub.net" uses a numeral 1 in place of the letter "i". Authentic DocuSign emails always originate from docusign.net or docusign.com.',
        severity: 'critical'
      },
      {
        id: 'rf-doc-2',
        location: 'link',
        title: 'Mismatched Target Destination',
        description: 'The CTA link directs to an unauthorized external web server designed to prompt for Office 365 or Google Workspace credentials.',
        severity: 'critical'
      }
    ]
  },
  {
    id: 'tmpl-quishing-mfa',
    name: 'Mobile Authenticator QR Re-Enrollment (Quishing)',
    attackVector: 'QR Code Quishing',
    difficulty: 5,
    senderName: 'Identity & Access Support (Okta / Duo)',
    senderEmail: 'identity-secops@auth-duo-gateway-mfa.io',
    displayDomain: 'auth-duo-gateway-mfa.io',
    realDomain: 'auth-duo-gateway-mfa.io',
    subject: 'ACTION REQUIRED: Security Token QR Scan for Mandatory 2FA Upgrade',
    preheader: 'Scan your personal token with your mobile camera to maintain device sync.',
    dateSent: 'Today at 07:15 AM',
    displayLinkText: 'Scan Embedded QR Code on Device',
    simulatedLinkUrl: 'https://auth-duo-gateway-mfa.io/enroll/mobile-token-session',
    landingPageType: 'qr_auth',
    explanationSummary: 'A state-of-the-art "Quishing" (QR Code Phishing) simulation. Attackers embed QR codes in images because email gateways struggle to parse and scan QR payloads, tricking users into switching to personal mobile devices where corporate endpoint protections are absent.',
    historicalClickRate: 31.8,
    htmlContent: `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background: #ffffff;">
        <div style="background-color: #0f172a; padding: 20px 24px; color: #ffffff;">
          <div style="font-size: 16px; font-weight: 700; letter-spacing: 0.5px;">ENTERPRISE IDENTITY ACCESS</div>
          <div style="font-size: 12px; color: #94a3b8; margin-top: 4px;">Zero-Trust Architecture Migration Notice</div>
        </div>

        <div style="padding: 24px;">
          <p style="font-size: 14px; margin-top: 0; color: #334155;">
            As part of our updated compliance requirements (SOC 2 CC6.1 & FIDO2 upgrade), all personnel mobile authenticator devices must be refreshed before 5:00 PM today.
          </p>

          <div style="border: 2px dashed #cbd5e1; border-radius: 8px; padding: 20px; text-align: center; background-color: #f8fafc; margin: 20px 0;">
            <div style="font-size: 13px; font-weight: 600; color: #0f172a; margin-bottom: 12px;">
              Scan using your mobile phone camera to re-link your device:
            </div>
            
            <!-- Simulated QR Code SVG representation -->
            <a href="#simulate-click" style="display: inline-block; padding: 12px; background: white; border: 1px solid #e2e8f0; border-radius: 6px; cursor: pointer; text-decoration: none;">
              <svg width="150" height="150" viewBox="0 0 100 100" style="display: block;">
                <!-- QR Finder patterns -->
                <rect x="5" y="5" width="28" height="28" fill="#0f172a"/>
                <rect x="9" y="9" width="20" height="20" fill="#ffffff"/>
                <rect x="13" y="13" width="12" height="12" fill="#0f172a"/>
                
                <rect x="67" y="5" width="28" height="28" fill="#0f172a"/>
                <rect x="71" y="9" width="20" height="20" fill="#ffffff"/>
                <rect x="75" y="13" width="12" height="12" fill="#0f172a"/>

                <rect x="5" y="67" width="28" height="28" fill="#0f172a"/>
                <rect x="9" y="71" width="20" height="20" fill="#ffffff"/>
                <rect x="13" y="75" width="12" height="12" fill="#0f172a"/>

                <!-- QR matrix dots -->
                <rect x="38" y="10" width="6" height="6" fill="#0f172a"/>
                <rect x="48" y="16" width="6" height="6" fill="#0f172a"/>
                <rect x="38" y="24" width="6" height="6" fill="#0f172a"/>
                <rect x="54" y="28" width="6" height="6" fill="#0f172a"/>
                <rect x="10" y="38" width="6" height="6" fill="#0f172a"/>
                <rect x="22" y="44" width="6" height="6" fill="#0f172a"/>
                <rect x="38" y="44" width="24" height="24" fill="#0f172a"/>
                <rect x="42" y="48" width="16" height="16" fill="#ffffff"/>
                <rect x="46" y="52" width="8" height="8" fill="#0f172a"/>
                <rect x="70" y="40" width="6" height="6" fill="#0f172a"/>
                <rect x="82" y="48" width="6" height="6" fill="#0f172a"/>
                <rect x="76" y="60" width="6" height="6" fill="#0f172a"/>
                <rect x="40" y="74" width="6" height="6" fill="#0f172a"/>
                <rect x="52" y="82" width="6" height="6" fill="#0f172a"/>
                <rect x="68" y="74" width="6" height="6" fill="#0f172a"/>
                <rect x="80" y="82" width="6" height="6" fill="#0f172a"/>
              </svg>
              <span style="font-size: 11px; color: #2563eb; display: block; margin-top: 6px; font-weight: 500;">[Click or Tap QR to Test]</span>
            </a>

            <div style="font-size: 11px; color: #64748b; margin-top: 12px;">
              Session Token #QZ-8891-B · Direct encrypted protocol
            </div>
          </div>

          <p style="font-size: 13px; color: #64748b;">
            Do not forward this message. QR authentication tokens are personal and tied to your hardware fingerprint.
          </p>
        </div>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-q-1',
        location: 'body',
        title: 'Quishing Vector (Off-Device Evasion)',
        description: 'Attackers use QR codes to move the victim from corporate-managed workstations (with EDR and browser inspection) onto personal smartphones with zero defensive telemetry.',
        severity: 'critical'
      },
      {
        id: 'rf-q-2',
        location: 'sender',
        title: 'Non-Corporate Identity Domain',
        description: 'Sender domain "auth-duo-gateway-mfa.io" is not your company domain nor legitimate Cisco/Duo infrastructure (duo.com).',
        severity: 'critical'
      }
    ]
  },
  {
    id: 'tmpl-hr-bonus',
    name: 'HR Benefits: 2026 Open Enrollment 401(k) Matching Adjustment',
    attackVector: 'HR / Payroll Urgent Trap',
    difficulty: 2,
    senderName: 'Corporate People Operations & Benefits',
    senderEmail: 'benefits-notice@hr-workday-portal-enrollment.com',
    displayDomain: 'hr-workday-portal-enrollment.com',
    realDomain: 'hr-workday-portal-enrollment.com',
    subject: 'Action Required: Confirm your updated 401(k) company match tier before payroll close',
    preheader: 'Failure to confirm by Friday may result in matching contribution suspension.',
    dateSent: 'Yesterday at 02:11 PM',
    displayLinkText: 'Log In to Workday Benefits to Confirm Tier',
    simulatedLinkUrl: 'https://sso.hr-workday-portal-enrollment.com/benefits/elections',
    landingPageType: 'payroll_direct_deposit',
    explanationSummary: 'Preys on financial anxiety and desire for employer matching benefits. Employees are prone to clicking without inspecting the URL when it concerns their paycheck or retirement match.',
    historicalClickRate: 26.5,
    htmlContent: `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; color: #1e293b; line-height: 1.5; border: 1px solid #e2e8f0; border-radius: 6px; padding: 24px; background: #fff;">
        <div style="border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 18px;">
          <h2 style="margin: 0; font-size: 18px; color: #0284c7;">People & Culture · Annual Benefits Portal</h2>
        </div>
        
        <p style="font-size: 14px; margin-top: 0;">Dear Colleague,</p>
        <p style="font-size: 14px;">
          During our recent mid-year compensation audit, we updated the employer 401(k) matching tiers to 6% retroactive match. 
        </p>
        <p style="font-size: 14px;">
          To ensure your upcoming pay period calculates your eligible retirement contribution accurately, all active staff must verify their election tier before the payroll system freeze on <strong>Friday at 5:00 PM</strong>.
        </p>

        <div style="margin: 24px 0; text-align: center;">
          <a href="#simulate-click" style="background-color: #0284c7; color: #ffffff; padding: 12px 28px; text-decoration: none; font-size: 14px; font-weight: 600; border-radius: 4px; display: inline-block;">
            Log In to Workday Benefits to Confirm Tier
          </a>
        </div>

        <p style="font-size: 12px; color: #64748b;">
          If no confirmation is recorded by the cutoff date, contributions will default to the standard 0% non-participating index until the next open enrollment cycle in November.
        </p>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-hr-1',
        location: 'sender',
        title: 'Spoofed Workday Domain',
        description: 'Notice the domain "hr-workday-portal-enrollment.com" is a newly registered third-party domain, not your internal HR subdomain nor authentic workday.com.',
        severity: 'critical'
      },
      {
        id: 'rf-hr-2',
        location: 'body',
        title: 'Negative Financial Consequence Leverage',
        description: 'Claims contributions will "default to 0%" to trigger fear and cause the victim to rush into entering credentials.',
        severity: 'high'
      }
    ]
  },
  {
    id: 'tmpl-vendor-invoice',
    name: 'Supply Chain: Overdue AWS / Cloud Infrastructure Invoice',
    attackVector: 'Supply Chain / Vendor Spoof',
    difficulty: 3,
    senderName: 'Amazon Web Services Billing Dispatch',
    senderEmail: 'no-reply-billing@aws-billing-notification-center.com',
    displayDomain: 'aws-billing-notification-center.com',
    realDomain: 'aws-billing-notification-center.com',
    subject: 'URGENT: Cloud Services Suspension Notice - Account #9081-3321-AWS',
    preheader: 'Payment past due: $3,412.80. Production servers will be throttled in 24 hours.',
    dateSent: 'Today at 06:50 AM',
    hasAttachment: true,
    attachmentName: 'Invoice_AWS_Overdue_Statement.html.exe',
    attachmentType: 'Executable File disguised as HTML',
    displayLinkText: 'Review Open Invoice Statement & Update Billing',
    simulatedLinkUrl: 'https://aws-billing-notification-center.com/resolve/past-due',
    landingPageType: 'it_ticket_portal',
    explanationSummary: 'Disguises malicious executable payloads as cloud billing statements, targeting engineering, DevOps, and IT operations staff with threats of server shutdown.',
    historicalClickRate: 19.3,
    htmlContent: `
      <div style="font-family: 'Amazon Ember', Arial, sans-serif; max-width: 600px; color: #232f3e; line-height: 1.5; border: 1px solid #eaeded; padding: 24px; background: #fff;">
        <div style="background-color: #232f3e; padding: 14px 20px; margin: -24px -24px 20px -24px;">
          <span style="color: #ff9900; font-size: 20px; font-weight: 700;">aws</span>
          <span style="color: #ffffff; font-size: 14px; margin-left: 10px;">Billing & Cost Management</span>
        </div>

        <h3 style="color: #d13212; font-size: 16px; margin-top: 0;">Account Suspension Warning</h3>
        <p style="font-size: 14px;">Dear AWS Customer,</p>
        <p style="font-size: 14px;">
          We were unable to process the automatic monthly settlement for AWS Account ID <strong>9081-3321-AWS</strong> in the amount of <strong>$3,412.80 USD</strong>.
        </p>
        <p style="font-size: 14px;">
          Your EC2 instances and RDS database clusters will be placed in <em>restricted maintenance shutdown</em> if payment is not confirmed within 24 hours.
        </p>

        <div style="margin: 24px 0;">
          <a href="#simulate-click" style="background-color: #ec7211; color: #ffffff; padding: 12px 24px; text-decoration: none; font-size: 14px; font-weight: 600; border-radius: 4px; display: inline-block;">
            Review Open Invoice Statement & Update Billing
          </a>
        </div>

        <div style="background: #f2f3f3; padding: 12px; border-radius: 4px; font-size: 12px;">
          <strong>Attachment:</strong> <span style="color: #0073bb; text-decoration: underline;">Invoice_AWS_Overdue_Statement.html.exe</span> (384 KB)
        </div>
      </div>
    `,
    redFlags: [
      {
        id: 'rf-aws-1',
        location: 'attachment',
        title: 'Double File Extension (Disguised Malware)',
        description: 'Notice the file name ends with ".html.exe". Windows often hides file extensions, causing users to mistake an executable virus for a web page.',
        severity: 'critical'
      },
      {
        id: 'rf-aws-2',
        location: 'sender',
        title: 'Non-AWS Domain',
        description: 'Official AWS billing emails come exclusively from @amazon.com or @amazonaws.com, not "aws-billing-notification-center.com".',
        severity: 'critical'
      }
    ]
  }
];

export const INITIAL_CAMPAIGNS: PhishingCampaign[] = [
  {
    id: 'camp-101',
    name: 'Q3 Enterprise Baseline: Microsoft 365 Expiration Test',
    targetDepartment: 'All Organization',
    templateId: 'tmpl-m365-session',
    templateName: 'Microsoft 365: Urgent Password & Session Expiry',
    attackVector: 'Credential Harvesting',
    status: 'Active',
    scheduledDate: '2026-09-20',
    totalSent: 1420,
    openedCount: 1148,
    clickedCount: 168,
    reportedCount: 782,
    compromisedCount: 38
  },
  {
    id: 'camp-102',
    name: 'Finance & Accounting Spear Phish: CEO Wire Request',
    targetDepartment: 'Finance & Accounting',
    templateId: 'tmpl-bec-wire',
    templateName: 'Executive Wire Transfer Request (CEO Fraud)',
    attackVector: 'Business Email Compromise (BEC)',
    status: 'Active',
    scheduledDate: '2026-09-24',
    totalSent: 68,
    openedCount: 59,
    clickedCount: 6,
    reportedCount: 49,
    compromisedCount: 1
  },
  {
    id: 'camp-103',
    name: 'HR Open Enrollment Benefit Phish Test',
    targetDepartment: 'All Organization',
    templateId: 'tmpl-hr-bonus',
    templateName: 'HR Benefits: 2026 Open Enrollment 401(k) Matching Adjustment',
    attackVector: 'HR / Payroll Urgent Trap',
    status: 'Completed',
    scheduledDate: '2026-09-02',
    totalSent: 1390,
    openedCount: 1220,
    clickedCount: 224,
    reportedCount: 694,
    compromisedCount: 52
  },
  {
    id: 'camp-104',
    name: 'Engineering & DevOps: AWS Invoice Disguised Attachment',
    targetDepartment: 'Engineering',
    templateId: 'tmpl-vendor-invoice',
    templateName: 'Supply Chain: Overdue AWS / Cloud Infrastructure Invoice',
    attackVector: 'Supply Chain / Vendor Spoof',
    status: 'Completed',
    scheduledDate: '2026-08-15',
    totalSent: 340,
    openedCount: 310,
    clickedCount: 28,
    reportedCount: 242,
    compromisedCount: 5
  },
  {
    id: 'camp-105',
    name: 'Zero-Trust Migration: Okta Quishing Mobile Test',
    targetDepartment: 'All Organization',
    templateId: 'tmpl-quishing-mfa',
    templateName: 'Mobile Authenticator QR Re-Enrollment (Quishing)',
    attackVector: 'QR Code Quishing',
    status: 'Scheduled',
    scheduledDate: '2026-10-05',
    totalSent: 1450,
    openedCount: 0,
    clickedCount: 0,
    reportedCount: 0,
    compromisedCount: 0
  }
];

export const INITIAL_MICROLEARNING_COURSES: MicrolearningCourse[] = [
  {
    id: 'course-bec-01',
    title: 'Defeating BEC & CEO Wire Fraud',
    slug: 'defeating-bec-ceo-fraud',
    durationMinutes: 4,
    category: 'Executive Protection',
    difficulty: 'Intermediate',
    complianceFrameworks: ['SOC 2 CC6.1', 'ISO 27001 A.6.3', 'NIST PR.AT-1'],
    summary: 'Master the high-pressure psychology of Business Email Compromise (BEC). Learn how attackers exploit urgency and executive authority, and master out-of-band verification.',
    keyTakeaways: [
      'Urgency + Secrecy + Payment = 99% probability of social engineering',
      'Never reply to the same thread to verify—attackers control the mailbox or reply-to address',
      'Always use an established out-of-band channel (official directory phone number) for any wire modifications'
    ],
    scenarioSteps: [
      {
        id: 'step-1',
        stepNumber: 1,
        situation: 'It is Friday at 4:50 PM. You receive an email from the CEO saying they are in confidential board negotiations for an acquisition. They instruct you to immediately execute an urgent wire of $65,000 to a new escrow account before the bank closes at 5:00 PM.',
        contextKicker: 'Scenario Decision: High Pressure Authority',
        choices: [
          {
            id: 'c-1',
            text: 'Process the wire immediately to avoid angering the CEO or jeopardizing the board acquisition.',
            isCorrect: false,
            feedback: 'Critical Security Failure! Attackers intentionally engineer Friday afternoon deadlines because fatigue and fear of executive reprimand bypass rational checks. Over $2.7 Billion was lost to BEC in 2024 using this exact scenario.',
            riskImpact: 'Loss of $65,000 with zero recourse; severe audit exception.'
          },
          {
            id: 'c-2',
            text: 'Reply to the email asking the CEO to provide written confirmation of the account routing number.',
            isCorrect: false,
            feedback: 'Vulnerable action! If the CEO’s account is compromised or if the Reply-To header redirects to the attacker’s inbox, the attacker will simply reply "Yes, confirmed, hurry up!".',
            riskImpact: 'Attacker maintains control of the conversation channel.'
          },
          {
            id: 'c-3',
            text: 'Pause transaction. Initiate Out-of-Band (OOB) verification by calling the CEO or CFO on their pre-registered internal corporate telephone number.',
            isCorrect: true,
            feedback: 'Defensive Gold Standard! Authentic dual-control policy requires contacting the requester via a known, pre-established voice or video channel before any funds move or bank coordinates change.',
            riskImpact: 'Attack thwarted immediately; incident ticket filed with SOC.'
          }
        ]
      },
      {
        id: 'step-2',
        stepNumber: 2,
        situation: 'The requester’s assistant pings you on Slack from an unverified guest handle saying: "Did you wire the funds yet? David is waiting on the board line."',
        contextKicker: 'Scenario Decision: Multi-Channel Follow-up',
        choices: [
          {
            id: 'c-4',
            text: 'Take a screenshot and report the external account to the Security Operations Center (SOC) while notifying your direct supervisor.',
            isCorrect: true,
            feedback: 'Spot on! Coordinated multi-channel social engineering is designed to overwhelm your hesitation. Flagging it to the SOC immediately enables domain blocking organization-wide.',
            riskImpact: 'Protects the entire company from a parallel multi-pronged attack.'
          },
          {
            id: 'c-5',
            text: 'Send the assistant a partial payment receipt to placate them while you wait.',
            isCorrect: false,
            feedback: 'Never send financial or internal operational details to unverified contacts.',
            riskImpact: 'Provides reconnaissance data to threat actors.'
          }
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'q-1',
        question: 'What is the primary indicator that an urgent financial request from leadership is a BEC attempt?',
        options: [
          'It is sent from an iPhone',
          'It combines extreme urgency, demands secrecy, and directs funds to an altered bank account',
          'It includes a PDF attachment',
          'It has a polite greeting'
        ],
        correctIndex: 1,
        explanation: 'The triad of high urgency, secrecy ("don’t mention this to anyone yet"), and bank account changes is the hallmark of BEC fraud.'
      },
      {
        id: 'q-2',
        question: 'Why is replying to the email to confirm authenticity considered dangerous?',
        options: [
          'Email servers charge extra for verification replies',
          'The attacker may have altered the Reply-To address or compromised the mailbox, so you are verifying with the criminal',
          'It slows down genuine company business',
          'It will cause your computer to reboot'
        ],
        correctIndex: 1,
        explanation: 'If an account is hijacked or using lookalike headers, the attacker replies with fraudulent confirmations.'
      }
    ],
    badgeReward: {
      title: 'BEC Defense Specialist',
      description: 'Mastered out-of-band wire verification and executive impersonation defense.',
      iconName: 'ShieldAlert'
    }
  },
  {
    id: 'course-quishing-02',
    title: 'Quishing: Unmasking QR Code Phishing',
    slug: 'quishing-qr-code-phishing',
    durationMinutes: 3,
    category: 'Emerging Threat Vectors',
    difficulty: 'Beginner',
    complianceFrameworks: ['SOC 2 CC6.3', 'ISO 27001 A.6.3', 'HIPAA 164.308'],
    summary: 'QR codes are convenient, but cybercriminals use them to bypass email gateway filters and shift attacks onto unmonitored personal smartphones. Learn to spot malicious QR traps.',
    keyTakeaways: [
      'QR codes in emails are an active evasion technique designed to defeat enterprise firewalls',
      'Never scan a QR code inside an email to "authenticate" or "upgrade" enterprise security',
      'Inspect the embedded destination URL in your camera app preview before opening any link'
    ],
    scenarioSteps: [
      {
        id: 'q-step-1',
        stepNumber: 1,
        situation: 'An email branded as IT Helpdesk asks you to scan a QR code to "migrate your authenticator app to the new corporate SSO cluster" or face account lock.',
        contextKicker: 'Scenario Decision: QR Code in Email',
        choices: [
          {
            id: 'qc-1',
            text: 'Pull out your phone, point camera, and tap the link without inspecting the URL.',
            isCorrect: false,
            feedback: 'Compromised! This takes you to a counterfeit portal on your phone where enterprise password managers and EDR cannot protect you.',
            riskImpact: 'Session cookies and MFA tokens harvested by adversaries.'
          },
          {
            id: 'qc-2',
            text: 'Legitimate IT departments never distribute MFA enrollment QR codes via unauthenticated public emails. Report the email using the PhishShield button.',
            isCorrect: true,
            feedback: 'Accurate insight! Enterprise MFA enrollment is performed directly inside the authorized SSO portal (e.g. Okta / Azure portal) after logging in, never via a bare email graphic.',
            riskImpact: 'Zero credentials exposed; threat signature added to mail filter.'
          }
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'qq-1',
        question: 'Why do attackers increasingly embed QR codes in phishing emails instead of traditional hyperlinks?',
        options: [
          'QR codes load faster on 5G networks',
          'Traditional email security gateways analyze text links easily, but often cannot parse or follow URLs embedded in image-based QR codes',
          'QR codes are free to create',
          'Mobile browsers block all phishing'
        ],
        correctIndex: 1,
        explanation: 'Email gateways parse text and HTML links, but extracting and evaluating dynamic QR images requires specialized visual computer vision models.'
      }
    ],
    badgeReward: {
      title: 'Quishing Shield Certified',
      description: 'Demonstrated mastery in detecting mobile QR code phishing vectors.',
      iconName: 'QrCode'
    }
  },
  {
    id: 'course-cred-03',
    title: 'Credential Harvesting & Lookalike Domains',
    slug: 'credential-harvesting-lookalike-domains',
    durationMinutes: 4,
    category: 'Core Cyber Hygiene',
    difficulty: 'Beginner',
    complianceFrameworks: ['SOC 2 CC6.1', 'PCI-DSS 12.6', 'ISO 27001 A.6.3'],
    summary: 'Understand how attackers craft convincing clones of Microsoft 365, Google Workspace, and DocuSign to steal session tokens and passwords.',
    keyTakeaways: [
      'Inspect the top-level domain (TLD) and root domain, not just the prefix or subdomain',
      'Look out for typosquatting (e.g., rn instead of m, 1 instead of l or i)',
      'Use corporate password managers—they will refuse to autofill on spoofed domains'
    ],
    scenarioSteps: [
      {
        id: 'cr-step-1',
        stepNumber: 1,
        situation: 'You click a link to view a shared spreadsheet. The browser opens a page that looks identical to your Microsoft login, showing the URL: "https://login.microsoft.security-verify.net/oauth2". Your password manager does NOT autofill your password.',
        contextKicker: 'Scenario Decision: Password Manager Clue',
        choices: [
          {
            id: 'crc-1',
            text: 'Manually type in your email and master password because the password manager is being glitchy.',
            isCorrect: false,
            feedback: 'Danger! Password managers do not fail randomly—they match the exact registered root domain. Here, the root domain is "security-verify.net", not "microsoft.com".',
            riskImpact: 'Master credentials and active MFA session captured.'
          },
          {
            id: 'crc-2',
            text: 'Close the tab immediately. Recognize that the root domain is "security-verify.net" and report the phishing email.',
            isCorrect: true,
            feedback: 'Brilliant catch! The password manager refusing to autofill is one of the strongest technical indicators that you are on a spoofed phishing page.',
            riskImpact: 'Compromise averted.'
          }
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'cq-1',
        question: 'In the address "https://portal.docusign.com.external-verify-cloud.org/sign", what is the actual destination root domain?',
        options: [
          'docusign.com',
          'portal.docusign.com',
          'external-verify-cloud.org',
          'sign.org'
        ],
        correctIndex: 2,
        explanation: 'In domain syntax, the root domain sits immediately before the top-level domain suffix (.org). The attacker named their subdomain "portal.docusign.com" to mislead your eye.'
      }
    ],
    badgeReward: {
      title: 'Domain Inspector',
      description: 'Skilled in dissecting root domains, subdomains, and fake login portals.',
      iconName: 'KeyRound'
    }
  },
  {
    id: 'course-malware-04',
    title: 'Ransomware Vectors & Malicious Attachments',
    slug: 'ransomware-malicious-attachments',
    durationMinutes: 5,
    category: 'Malware Defense',
    difficulty: 'Advanced',
    complianceFrameworks: ['HIPAA 164.308', 'NIST PR.AT-2', 'ISO 27001 A.6.3'],
    summary: 'Explore how common office documents (.docx, .xlsx), ISO archives, and double-extension executables (.pdf.exe) drop initial access ransomware loaders.',
    keyTakeaways: [
      'Never enable macros or click "Enable Content" on unverified documents',
      'Be wary of password-protected ZIP or 7z files sent by unknown parties',
      'Check file extensions carefully: Windows often hides the real trailing extension'
    ],
    scenarioSteps: [
      {
        id: 'm-step-1',
        stepNumber: 1,
        situation: 'An email from an external vendor includes an encrypted ZIP file titled "Overdue_Payment_Statement_Encrypted.zip" with the password provided in the body: "Pass1234".',
        contextKicker: 'Scenario Decision: Password Protected ZIPs',
        choices: [
          {
            id: 'mc-1',
            text: 'Extract the file using the password because encrypted files are safer and more secure.',
            isCorrect: false,
            feedback: 'Common misconception! Attackers encrypt malware attachments specifically so that email security filters cannot inspect the contents before it reaches your inbox.',
            riskImpact: 'Bypasses perimeter gateway scanner; triggers ransomware payload.'
          },
          {
            id: 'mc-2',
            text: 'Treat password-protected archives from unsolicited senders as high-risk. Forward to the security team sandbox before extraction.',
            isCorrect: true,
            feedback: 'Security Pro Move! Encrypted archives with the password in the plaintext body are a notorious bypass technique.',
            riskImpact: 'Malware analyzed in quarantined sandbox without touching local workstation.'
          }
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'mq-1',
        question: 'Why do cybercriminals put passwords in the email body for encrypted attachments?',
        options: [
          'To comply with privacy laws like GDPR',
          'To prevent the recipient from losing the document',
          'To blindfold gateway antivirus scanners that cannot decrypt the attachment without the key',
          'It is required by Adobe Acrobat'
        ],
        correctIndex: 2,
        explanation: 'By encrypting the file, the automated mail server scanner cannot inspect the code, relying on the user to manually unzip the malware.'
      }
    ],
    badgeReward: {
      title: 'Malware Interceptor',
      description: 'Expertise in spotting evasive archives, macro traps, and ransomware delivery.',
      iconName: 'Virus'
    }
  },
  {
    id: 'course-clean-05',
    title: 'Data Privacy, Clean Desk & Physical Security',
    slug: 'data-privacy-clean-desk',
    durationMinutes: 3,
    category: 'Workplace Security',
    difficulty: 'Beginner',
    complianceFrameworks: ['HIPAA 164.308', 'SOC 2 CC6.1', 'ISO 27001 A.7.7'],
    summary: 'Digital security fails if physical and visual operational security is neglected. Learn guidelines for clean desks, screen locks, and tailgating.',
    keyTakeaways: [
      'Lock your screen every time you step away (Win + L / Cmd + Ctrl + Q)',
      'Never plug in unidentified USB flash drives found in parking lots or lobbies',
      'Never hold doors open for unbadged visitors—challenge or direct them to reception'
    ],
    scenarioSteps: [
      {
        id: 'cd-step-1',
        stepNumber: 1,
        situation: 'You are walking into the secure engineering facility with a coffee in both hands. A person in work attire carrying heavy boxes asks you to hold the badged door open.',
        contextKicker: 'Scenario Decision: Tailgating & Social Courtesy',
        choices: [
          {
            id: 'cdc-1',
            text: 'Hold the door open for them out of politeness.',
            isCorrect: false,
            feedback: 'Tailgating risk! Attackers exploit human politeness. Physical entry gives direct access to Ethernet drops, unattended workstations, and server closets.',
            riskImpact: 'Physical perimeter breach; audit penalty under ISO 27001 physical security controls.'
          },
          {
            id: 'cdc-2',
            text: 'Politely state: "Company policy requires all individuals to badge in independently. Let me escort you to the visitor registration desk."',
            isCorrect: true,
            feedback: 'Courteous and Secure! Proper security culture normalizes that legitimate staff understand and respect individual badging requirements.',
            riskImpact: 'Maintains unbroken physical chain-of-custody.'
          }
        ]
      }
    ],
    quizQuestions: [
      {
        id: 'cdq-1',
        question: 'What is the immediate action when finding a lost USB drive in the office lobby?',
        options: [
          'Plug it into your laptop to find the owner’s resume or photos',
          'Hand it over to IT Security without plugging it into any system',
          'Throw it in the regular trash bin',
          'Reformat it to get a free flash drive'
        ],
        correctIndex: 1,
        explanation: 'USB drop attacks use rogue microcontrollers (Rubber Ducky) that register as keyboards and inject automated keystroke payloads in seconds.'
      }
    ],
    badgeReward: {
      title: 'Physical Fortress Badge',
      description: 'Certified in anti-tailgating, clean desk policy, and hardware drop defense.',
      iconName: 'Lock'
    }
  }
];

export const INITIAL_COMPLIANCE_FRAMEWORKS: ComplianceFramework[] = [
  {
    id: 'soc2-type2',
    name: 'SOC 2 Type II',
    standardCode: 'AICPA TSC 2017 / Trust Services Criteria',
    readinessPercentage: 96,
    totalControls: 6,
    satisfiedControls: 6,
    auditorDescription: 'Evaluates controls over security, availability, and confidentiality. Requires continuous security awareness training and documented phishing simulation resistance testing.',
    controls: [
      {
        code: 'CC6.1',
        title: 'Logical Access & Security Training',
        description: 'The entity implements logical access security software, infrastructure, and architectures over the system, supported by mandatory security awareness education for all personnel.',
        status: 'Satisfied',
        complianceRate: 98.4,
        evidenceCount: 1420,
        lastAuditDate: '2026-08-15',
        nextRenewalDate: '2027-08-15'
      },
      {
        code: 'CC6.3',
        title: 'Workforce Phishing Simulation & Remediation',
        description: 'Workforce members receive simulated social engineering tests at least quarterly. Personnel who fail simulations receive mandatory remedial microlearning within 14 days.',
        status: 'Satisfied',
        complianceRate: 95.8,
        evidenceCount: 168,
        lastAuditDate: '2026-09-01',
        nextRenewalDate: '2027-09-01'
      },
      {
        code: 'CC6.6',
        title: 'Malicious Software Prevention & Reporting',
        description: 'Workforce members are trained to identify and promptly report suspected malicious software, unapproved attachments, or unauthorized software downloads.',
        status: 'Satisfied',
        complianceRate: 97.1,
        evidenceCount: 890,
        lastAuditDate: '2026-08-20',
        nextRenewalDate: '2027-08-20'
      }
    ]
  },
  {
    id: 'iso-27001',
    name: 'ISO/IEC 27001:2022',
    standardCode: 'Annex A Information Security Controls',
    readinessPercentage: 91,
    totalControls: 5,
    satisfiedControls: 4,
    auditorDescription: 'International standard for Information Security Management Systems (ISMS). Control A.6.3 requires regular security awareness, education, and updates on organizational policies.',
    controls: [
      {
        code: 'A.6.3',
        title: 'Information Security Awareness, Education and Training',
        description: 'Personnel of the organization and relevant interested parties shall receive appropriate information security awareness, education and training, and regular updates on organizational policies and procedures.',
        status: 'Satisfied',
        complianceRate: 94.2,
        evidenceCount: 1390,
        lastAuditDate: '2026-07-10',
        nextRenewalDate: '2027-07-10'
      },
      {
        code: 'A.7.7',
        title: 'Clear Desk and Clear Screen Rules',
        description: 'Clear desk rules for papers and removable storage media and clear screen rules for information processing facilities shall be defined and appropriately enforced.',
        status: 'Action Required',
        complianceRate: 82.0,
        evidenceCount: 94,
        lastAuditDate: '2026-09-12',
        nextRenewalDate: '2026-11-15',
        gapNotes: 'Physical audit identified 18 unlocked screens in Customer Support and Sales departments. Clean Desk microlearning refresher dispatched.'
      },
      {
        code: 'A.5.15',
        title: 'Access Control & Authentication Verification',
        description: 'Rules to control physical and logical access to information and other associated assets shall be established and implemented in accordance with business requirements.',
        status: 'Satisfied',
        complianceRate: 96.5,
        evidenceCount: 1412,
        lastAuditDate: '2026-08-30',
        nextRenewalDate: '2027-08-30'
      }
    ]
  },
  {
    id: 'hipaa-security',
    name: 'HIPAA Security Rule',
    standardCode: '45 CFR § 164.308(a)(5)',
    readinessPercentage: 94,
    totalControls: 4,
    satisfiedControls: 4,
    auditorDescription: 'Mandates administrative safeguards for covered entities and business associates to protect electronic Protected Health Information (ePHI) through security awareness and training.',
    controls: [
      {
        code: '§ 164.308(a)(5)(ii)(A)',
        title: 'Security Reminders & Periodic Bulletins',
        description: 'Periodic security updates, reminders, and phishing alerts distributed to all staff with access to systems handling ePHI.',
        status: 'Satisfied',
        complianceRate: 99.1,
        evidenceCount: 312,
        lastAuditDate: '2026-06-18',
        nextRenewalDate: '2027-06-18'
      },
      {
        code: '§ 164.308(a)(5)(ii)(B)',
        title: 'Protection from Malicious Software & Phishing',
        description: 'Procedures for guarding against, detecting, and reporting malicious software and phishing scams that could expose health records.',
        status: 'Satisfied',
        complianceRate: 93.4,
        evidenceCount: 1204,
        lastAuditDate: '2026-07-25',
        nextRenewalDate: '2027-07-25'
      },
      {
        code: '§ 164.308(a)(5)(ii)(D)',
        title: 'Password Management & Identity Hygiene',
        description: 'Procedures for creating, changing, and safeguarding strong authentication secrets and preventing credential harvesting.',
        status: 'Satisfied',
        complianceRate: 96.0,
        evidenceCount: 1420,
        lastAuditDate: '2026-08-14',
        nextRenewalDate: '2027-08-14'
      }
    ]
  },
  {
    id: 'pci-dss-v4',
    name: 'PCI-DSS v4.0',
    standardCode: 'Payment Card Industry Requirement 12.6',
    readinessPercentage: 88,
    totalControls: 4,
    satisfiedControls: 3,
    auditorDescription: 'Requires a formal security awareness program for all personnel upon hire and at least once every 12 months, with specific emphasis on phishing, social engineering, and cardholder data protection.',
    controls: [
      {
        code: 'Req 12.6.1',
        title: 'Formal Security Awareness Program',
        description: 'Implement a formal security awareness program to make all personnel aware of the importance of cardholder data security.',
        status: 'Satisfied',
        complianceRate: 92.5,
        evidenceCount: 1380,
        lastAuditDate: '2026-05-10',
        nextRenewalDate: '2027-05-10'
      },
      {
        code: 'Req 12.6.2',
        title: 'Phishing & Social Engineering Awareness',
        description: 'Security awareness program includes awareness of threats that could compromise cardholder data, including phishing and social engineering.',
        status: 'Satisfied',
        complianceRate: 94.0,
        evidenceCount: 1420,
        lastAuditDate: '2026-06-20',
        nextRenewalDate: '2027-06-20'
      },
      {
        code: 'Req 12.6.3.1',
        title: 'Role-Based Training on Technologies',
        description: 'Personnel in development, IT operations, and payment handling receive specialized role-based awareness on specific vulnerabilities and secure coding principles.',
        status: 'In Progress',
        complianceRate: 78.4,
        evidenceCount: 65,
        lastAuditDate: '2026-08-10',
        nextRenewalDate: '2026-11-01',
        gapNotes: '14 new engineering hires must complete Secure Code Awareness module before Q4 production freeze.'
      }
    ]
  }
];

export const INITIAL_EMPLOYEES: EmployeeRecord[] = [
  {
    id: 'emp-001',
    name: 'Alex Chen',
    email: 'alex.chen@enterprise-demo.com',
    department: 'Finance & Accounting',
    role: 'Senior Financial Analyst',
    phishProneScore: 2.1,
    riskTier: 'Low Risk',
    simulationsReceived: 12,
    simulationsReported: 11,
    simulationsClicked: 1,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-24',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: '12 mins ago'
  },
  {
    id: 'emp-002',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@enterprise-demo.com',
    department: 'Finance & Accounting',
    role: 'Accounts Payable Specialist',
    phishProneScore: 18.5,
    riskTier: 'High Risk',
    simulationsReceived: 12,
    simulationsReported: 4,
    simulationsClicked: 4,
    simulationsCompromised: 2,
    lastSimulationDate: '2026-09-24',
    lastSimulationOutcome: 'Compromised',
    assignedCoursesCount: 5,
    completedCoursesCount: 3,
    complianceStatus: 'Overdue',
    lastActive: '3 hours ago'
  },
  {
    id: 'emp-003',
    name: 'Marcus Brody',
    email: 'marcus.brody@enterprise-demo.com',
    department: 'Human Resources',
    role: 'VP People Operations',
    phishProneScore: 4.8,
    riskTier: 'Low Risk',
    simulationsReceived: 10,
    simulationsReported: 8,
    simulationsClicked: 1,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: '1 hour ago'
  },
  {
    id: 'emp-004',
    name: 'Elena Rostova',
    email: 'elena.rostova@enterprise-demo.com',
    department: 'Engineering',
    role: 'Principal Cloud Architect',
    phishProneScore: 1.2,
    riskTier: 'Low Risk',
    simulationsReceived: 14,
    simulationsReported: 13,
    simulationsClicked: 0,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: '5 mins ago'
  },
  {
    id: 'emp-005',
    name: 'Devon Vance',
    email: 'devon.vance@enterprise-demo.com',
    department: 'Sales & Marketing',
    role: 'Senior Account Executive',
    phishProneScore: 24.0,
    riskTier: 'High Risk',
    simulationsReceived: 11,
    simulationsReported: 3,
    simulationsClicked: 5,
    simulationsCompromised: 3,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Clicked',
    assignedCoursesCount: 5,
    completedCoursesCount: 2,
    complianceStatus: 'Overdue',
    lastActive: 'Yesterday'
  },
  {
    id: 'emp-006',
    name: 'Kavita Patel',
    email: 'kavita.patel@enterprise-demo.com',
    department: 'Legal & Compliance',
    role: 'Associate General Counsel',
    phishProneScore: 3.0,
    riskTier: 'Low Risk',
    simulationsReceived: 12,
    simulationsReported: 11,
    simulationsClicked: 1,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: '45 mins ago'
  },
  {
    id: 'emp-007',
    name: 'Lucas Wright',
    email: 'lucas.wright@enterprise-demo.com',
    department: 'Customer Support',
    role: 'Tier 2 Support Lead',
    phishProneScore: 14.2,
    riskTier: 'Moderate Risk',
    simulationsReceived: 9,
    simulationsReported: 5,
    simulationsClicked: 2,
    simulationsCompromised: 1,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Ignored',
    assignedCoursesCount: 5,
    completedCoursesCount: 4,
    complianceStatus: 'In Progress',
    lastActive: '2 hours ago'
  },
  {
    id: 'emp-008',
    name: 'Naomi Zhao',
    email: 'naomi.zhao@enterprise-demo.com',
    department: 'Executive Office',
    role: 'Executive Assistant to CEO',
    phishProneScore: 8.5,
    riskTier: 'Moderate Risk',
    simulationsReceived: 13,
    simulationsReported: 10,
    simulationsClicked: 2,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-24',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: '20 mins ago'
  },
  {
    id: 'emp-009',
    name: 'Tariq Al-Mansoor',
    email: 'tariq.almansoor@enterprise-demo.com',
    department: 'Engineering',
    role: 'Site Reliability Engineer',
    phishProneScore: 2.5,
    riskTier: 'Low Risk',
    simulationsReceived: 14,
    simulationsReported: 12,
    simulationsClicked: 1,
    simulationsCompromised: 0,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Reported',
    assignedCoursesCount: 5,
    completedCoursesCount: 5,
    complianceStatus: 'Compliant',
    lastActive: 'Just now'
  },
  {
    id: 'emp-010',
    name: 'Chloe Bennett',
    email: 'chloe.bennett@enterprise-demo.com',
    department: 'Sales & Marketing',
    role: 'Demand Gen Lead',
    phishProneScore: 16.8,
    riskTier: 'Moderate Risk',
    simulationsReceived: 10,
    simulationsReported: 4,
    simulationsClicked: 3,
    simulationsCompromised: 1,
    lastSimulationDate: '2026-09-20',
    lastSimulationOutcome: 'Clicked',
    assignedCoursesCount: 5,
    completedCoursesCount: 3,
    complianceStatus: 'In Progress',
    lastActive: '4 hours ago'
  }
];

export const INITIAL_EVENTS: SimulationEvent[] = [
  {
    id: 'ev-1',
    timestamp: 'Just now',
    employeeName: 'Elena Rostova',
    department: 'Engineering',
    campaignName: 'M365 Expiration Test',
    action: 'REPORTED',
    detail: 'Reported simulation in 42 seconds using PhishShield Outlook add-in'
  },
  {
    id: 'ev-2',
    timestamp: '4 mins ago',
    employeeName: 'Sarah Jenkins',
    department: 'Finance & Accounting',
    campaignName: 'CEO Wire Request',
    action: 'COMPROMISED',
    detail: 'Entered credentials on simulated wire portal. Instant remedial coaching triggered.'
  },
  {
    id: 'ev-3',
    timestamp: '11 mins ago',
    employeeName: 'Alex Chen',
    department: 'Finance & Accounting',
    campaignName: 'CEO Wire Request',
    action: 'REPORTED',
    detail: 'Flagged suspicious external reply-to header via security button'
  },
  {
    id: 'ev-4',
    timestamp: '28 mins ago',
    employeeName: 'Devon Vance',
    department: 'Sales & Marketing',
    campaignName: 'M365 Expiration Test',
    action: 'CLICKED',
    detail: 'Clicked simulated login link on mobile web browser'
  },
  {
    id: 'ev-5',
    timestamp: '46 mins ago',
    employeeName: 'Naomi Zhao',
    department: 'Executive Office',
    campaignName: 'CEO Wire Request',
    action: 'REPORTED',
    detail: 'Quarantined message; risk score decreased by -1.2%'
  },
  {
    id: 'ev-6',
    timestamp: '1 hour ago',
    employeeName: 'Lucas Wright',
    department: 'Customer Support',
    campaignName: 'M365 Expiration Test',
    action: 'OPENED',
    detail: 'Message opened; no interaction recorded after 15 minutes'
  }
];

export const DEPARTMENT_STATS = [
  { name: 'Engineering', size: 340, phishProneScore: 2.4, trainingCompletion: 98.2, riskLevel: 'Low' },
  { name: 'Legal & Compliance', size: 45, phishProneScore: 2.8, trainingCompletion: 100.0, riskLevel: 'Low' },
  { name: 'Executive Office', size: 18, phishProneScore: 4.1, trainingCompletion: 94.4, riskLevel: 'Low' },
  { name: 'Finance & Accounting', size: 68, phishProneScore: 8.9, trainingCompletion: 89.7, riskLevel: 'Moderate' },
  { name: 'Customer Support', size: 120, phishProneScore: 12.3, trainingCompletion: 82.5, riskLevel: 'Moderate' },
  { name: 'Sales & Marketing', size: 210, phishProneScore: 19.4, trainingCompletion: 76.1, riskLevel: 'High' }
];
