import React from 'react';
import { 
  MicrolearningCourse, 
  EmployeeRecord 
} from '../../types';
import { 
  ShieldCheck, 
  Award, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Mail, 
  ScanSearch, 
  ChevronRight,
  TrendingUp,
  Sparkles
} from 'lucide-react';

interface LearnerPortalViewProps {
  currentUser: EmployeeRecord;
  courses: MicrolearningCourse[];
  onStartCourse: (slug: string) => void;
  onOpenPracticeLab: () => void;
}

export const LearnerPortalView: React.FC<LearnerPortalViewProps> = ({
  currentUser,
  courses,
  onStartCourse,
  onOpenPracticeLab
}) => {
  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-950/70 via-indigo-950/40 to-slate-900 border border-blue-800/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Employee Security Hub</span>
            </div>
            <h1 className="text-xl font-bold text-white">
              Welcome back, {currentUser.name}!
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              You are currently ranked in the top <strong className="text-emerald-400">5% of vigilant employees</strong>. Keep reporting suspicious emails to earn Security Champion badges.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-900/80 border border-slate-800 p-4 rounded-xl shrink-0">
            <div>
              <div className="text-[11px] text-slate-400">My Phish-Prone %</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                {currentUser.phishProneScore}%
              </div>
              <div className="text-[10px] text-emerald-400 mt-0.5">Zero credentials breached</div>
            </div>
            <div className="w-px h-10 bg-slate-800" />
            <div>
              <div className="text-[11px] text-slate-400">Simulations Caught</div>
              <div className="text-2xl font-bold font-mono text-blue-400 tabular-nums">
                {currentUser.simulationsReported} / {currentUser.simulationsReceived}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">91.6% report speed</div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Assigned Training Modules & Practice Lab */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Assigned Training */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-400" />
              <span>My Security Training Curriculum</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">
              {currentUser.completedCoursesCount} of {currentUser.assignedCoursesCount} Completed
            </span>
          </div>

          <div className="space-y-3">
            {courses.slice(0, 4).map((course, idx) => {
              const isCompleted = idx < currentUser.completedCoursesCount;

              return (
                <div
                  key={course.id}
                  className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-700 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-blue-400">
                        {course.category}
                      </span>
                      <span className="text-slate-600">·</span>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3" />
                        <span>{course.durationMinutes} min</span>
                      </span>
                      {isCompleted && (
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-1.5 py-0.5 rounded">
                          COMPLETED
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold text-white">{course.title}</h3>
                    <p className="text-xs text-slate-400 line-clamp-1">{course.summary}</p>
                  </div>

                  <button
                    onClick={() => onStartCourse(course.slug)}
                    className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shrink-0 ${
                      isCompleted
                        ? 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm'
                    }`}
                  >
                    <span>{isCompleted ? 'Review Module' : 'Start (3 min)'}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Badges & Practice Simulator */}
        <div className="lg:col-span-4 space-y-5">
          {/* Practice Sandbox CTA */}
          <div className="p-5 rounded-xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-800/40">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
              <ScanSearch className="w-4 h-4" />
              <span>Interactive Practice Lab</span>
            </div>
            <h3 className="text-sm font-bold text-white mb-1">
              Test Your Phish-Detecting Skills
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Step into the ThreatLab sandbox to inspect suspicious emails, spot red flags, and practice using the 1-click report button.
            </p>
            <button
              onClick={onOpenPracticeLab}
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              <span>Launch ThreatLab Sandbox</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Badges Showcase */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-400" />
                <span>Earned Security Badges</span>
              </h3>
              <span className="text-[11px] font-mono text-emerald-400 font-bold">3 Unlocked</span>
            </div>

            <div className="space-y-2">
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400 text-sm">
                  🛡️
                </div>
                <div>
                  <div className="text-xs font-bold text-white">BEC Defense Specialist</div>
                  <div className="text-[10px] text-slate-400">Identified CEO wire spoof under 45s</div>
                </div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-950/60 border border-blue-800/60 flex items-center justify-center text-blue-400 text-sm">
                  📱
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Quishing Shield Certified</div>
                  <div className="text-[10px] text-slate-400">Mastered QR code camera inspection</div>
                </div>
              </div>

              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-950/60 border border-amber-800/60 flex items-center justify-center text-amber-400 text-sm">
                  🔍
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Domain Inspector</div>
                  <div className="text-[10px] text-slate-400">Detected typosquatted lookalike URLs</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
