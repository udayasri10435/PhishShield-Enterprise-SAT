import React, { useState } from 'react';
import { 
  PhishingTemplate, 
  RedFlag 
} from '../../types';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  Eye, 
  EyeOff, 
  Send, 
  ExternalLink, 
  Lock, 
  ChevronRight, 
  RefreshCw,
  Mail,
  FileText,
  CornerUpLeft,
  Flame,
  Award,
  BookOpen
} from 'lucide-react';

interface ThreatLabInspectorProps {
  templates: PhishingTemplate[];
  selectedTemplateId?: string;
  onSelectTemplate: (templateId: string) => void;
  onStartCourse: (courseSlug: string) => void;
  onRecordSimulationEvent: (action: 'REPORTED' | 'CLICKED' | 'COMPROMISED', detail: string) => void;
}

export const ThreatLabInspector: React.FC<ThreatLabInspectorProps> = ({
  templates,
  selectedTemplateId,
  onSelectTemplate,
  onStartCourse,
  onRecordSimulationEvent
}) => {
  const currentTemplate = templates.find(t => t.id === selectedTemplateId) || templates[0];
  
  // Interactive state
  const [radarActive, setRadarActive] = useState<boolean>(false);
  const [selectedFlag, setSelectedFlag] = useState<RedFlag | null>(null);
  const [showLandingPageModal, setShowLandingPageModal] = useState<boolean>(false);
  const [showTeachMomentModal, setShowTeachMomentModal] = useState<boolean>(false);
  const [showReportSuccessModal, setShowReportSuccessModal] = useState<boolean>(false);
  
  // Fake credentials input for landing page simulation
  const [fakeInput, setFakeInput] = useState({ username: 'alex.chen@enterprise-demo.com', password: '' });

  const handleSimulateClickLink = (e: React.MouseEvent) => {
    e.preventDefault();
    onRecordSimulationEvent('CLICKED', `Clicked link in '${currentTemplate.name}' simulation`);
    setShowLandingPageModal(true);
  };

  const handleFakeSubmitCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setShowLandingPageModal(false);
    onRecordSimulationEvent('COMPROMISED', `Submitted simulated credentials on '${currentTemplate.name}'`);
    setShowTeachMomentModal(true);
  };

  const handleReportPhish = () => {
    onRecordSimulationEvent('REPORTED', `Quarantined and reported '${currentTemplate.name}' via PhishShield add-in`);
    setShowReportSuccessModal(true);
  };

  const mapVectorToCourseSlug = (vector: string) => {
    if (vector.includes('BEC')) return 'defeating-bec-ceo-fraud';
    if (vector.includes('QR')) return 'quishing-qr-code-phishing';
    if (vector.includes('Attachment') || vector.includes('Ransomware') || vector.includes('Supply')) return 'ransomware-malicious-attachments';
    return 'credential-harvesting-lookalike-domains';
  };

  return (
    <div className="space-y-6">
      {/* Top Controller Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Simulated Attack:
          </label>
          <select 
            value={currentTemplate.id}
            onChange={(e) => {
              onSelectTemplate(e.target.value);
              setSelectedFlag(null);
            }}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-2 font-medium focus:outline-none focus:border-blue-500"
          >
            {templates.map(tmpl => (
              <option key={tmpl.id} value={tmpl.id}>
                [{tmpl.attackVector}] {tmpl.name}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-1.5 text-xs text-slate-400 pl-2">
            <span>Difficulty:</span>
            <div className="flex text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <span key={i} className={i < currentTemplate.difficulty ? 'text-amber-400' : 'text-slate-700'}>
                  ★
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Toolbar Affordances */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setRadarActive(!radarActive)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 border ${
              radarActive 
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/10' 
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
            }`}
          >
            {radarActive ? <Eye className="w-3.5 h-3.5 text-amber-400" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Red Flag Radar ({currentTemplate.redFlags.length})</span>
          </button>

          <button
            onClick={handleReportPhish}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-blue-200" />
            <span>Report Phish (Simulate)</span>
          </button>
        </div>
      </div>

      {/* Main Email Client Canvas + Analysis Panel */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Email Client Viewport (Simulates Outlook Web / Google Workspace Mail) */}
        <div className="xl:col-span-8 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
          {/* Outlook-style Mock Header */}
          <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-blue-400" />
                <span>Enterprise Mailbox Client</span>
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400 font-mono text-[11px]">INBOX / External Message</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-amber-400/90 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded font-medium">
                [External Sender]
              </span>
            </div>
          </div>

          {/* Email Headers Inspection Table */}
          <div className="p-5 border-b border-slate-800/80 bg-slate-950/40 text-xs space-y-3">
            {/* Subject */}
            <div className="flex items-baseline justify-between">
              <h1 className="text-base font-bold text-white tracking-tight">
                {currentTemplate.subject}
              </h1>
              <span className="text-slate-500 font-mono text-[11px] shrink-0 ml-4 tabular-nums">
                {currentTemplate.dateSent}
              </span>
            </div>

            {/* Sender / From */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-xs shrink-0">
                  {currentTemplate.senderName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-200">{currentTemplate.senderName}</span>
                    <span className={`text-[11px] font-mono px-1.5 py-0.5 rounded transition-all ${
                      radarActive 
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-700/80 ring-2 ring-rose-500/40' 
                        : 'text-slate-400 bg-slate-900 border border-slate-800'
                    }`}>
                      &lt;{currentTemplate.senderEmail}&gt;
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                    <span>To:</span>
                    <span className="text-slate-400">alex.chen@acme-global.corp</span>
                    {currentTemplate.replyTo && (
                      <>
                        <span>·</span>
                        <span>Reply-To:</span>
                        <span className={`font-mono text-[11px] px-1 rounded ${
                          radarActive ? 'bg-amber-950 text-amber-300 border border-amber-700' : 'text-slate-400'
                        }`}>
                          {currentTemplate.replyTo}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Technical Gateway Telemetry */}
              <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-400 bg-slate-900/90 px-2 py-1 rounded border border-slate-800 shrink-0">
                <span>SPF:</span>
                <span className="text-rose-400 font-bold">SoftFail</span>
                <span className="text-slate-600">|</span>
                <span>DKIM:</span>
                <span className="text-amber-400">Neutral</span>
              </div>
            </div>
          </div>

          {/* Email Body Rendering */}
          <div className="p-6 bg-slate-950 min-h-[380px] flex flex-col justify-between">
            {/* The actual HTML template content styled */}
            <div 
              className="prose prose-invert max-w-none text-slate-300"
              onClick={(e) => {
                const target = e.target as HTMLElement;
                if (target.tagName === 'A' || target.closest('a')) {
                  handleSimulateClickLink(e);
                }
              }}
              dangerouslySetInnerHTML={{ __html: currentTemplate.htmlContent }}
            />

            {/* Test Trigger Helper (Explicit simulation trigger) */}
            <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5 text-slate-500">
                <Info className="w-4 h-4 text-blue-400" />
                Hover or click buttons in the email to experience the victim path.
              </span>
              <button
                onClick={handleSimulateClickLink}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium underline flex items-center gap-1"
              >
                <span>Trigger Employee Click Test</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Threat Analysis & Red Flag Radar Inspector Panel */}
        <div className="xl:col-span-4 space-y-4">
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Threat Vector Analysis</span>
              </h2>
              <span className="text-xs font-mono font-semibold text-slate-400">
                {currentTemplate.attackVector}
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {currentTemplate.explanationSummary}
            </p>

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Industry Avg Click Rate:</span>
              <span className="font-mono font-bold text-rose-400 tabular-nums">
                {currentTemplate.historicalClickRate}%
              </span>
            </div>
          </div>

          {/* Interactive Red Flag Radar Breakdown */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Identified Indicators of Compromise (IoC)
              </h3>
              <span className="text-xs font-mono text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/60">
                {currentTemplate.redFlags.length} Signals
              </span>
            </div>

            <div className="space-y-2.5">
              {currentTemplate.redFlags.map((flag) => (
                <div 
                  key={flag.id}
                  onClick={() => setSelectedFlag(flag)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedFlag?.id === flag.id
                      ? 'bg-amber-950/40 border-amber-500/60 ring-1 ring-amber-500/40'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-200">{flag.title}</span>
                    <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      flag.severity === 'critical' 
                        ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {flag.severity}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    {flag.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Connected Remedial Microlearning Module Card */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-blue-950/40 to-indigo-950/30 border border-blue-800/40">
            <div className="text-xs font-semibold text-blue-400 mb-1 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Recommended Remedial Course</span>
            </div>
            <div className="text-xs font-bold text-white mb-2">
              Countering {currentTemplate.attackVector}
            </div>
            <p className="text-[11px] text-slate-300 mb-3">
              Assign or test the interactive 3-minute scenario module associated with this attack vector.
            </p>
            <button
              onClick={() => onStartCourse(mapVectorToCourseSlug(currentTemplate.attackVector))}
              className="w-full py-2 px-3 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Launch 3-Min Interactive Module</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* POPUP 1: Fake Phishing Landing Page (When user clicks link) */}
      {showLandingPageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-md w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95">
            {/* Fake browser address bar */}
            <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center gap-2 text-xs">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              </div>
              <div className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-[11px] font-mono text-rose-300 truncate flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-rose-400" />
                <span>{currentTemplate.simulatedLinkUrl}</span>
              </div>
            </div>

            {/* Landing page body */}
            <div className="p-6 bg-slate-900">
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-blue-600/20 text-blue-400 rounded-xl flex items-center justify-center mx-auto mb-3 border border-blue-500/30">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white">
                  Corporate Single Sign-On Gateway
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Authenticate your enterprise credentials to access protected resource.
                </p>
              </div>

              <form onSubmit={handleFakeSubmitCredentials} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Corporate Email ID
                  </label>
                  <input 
                    type="email"
                    value={fakeInput.username}
                    onChange={(e) => setFakeInput({ ...fakeInput, username: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Password / MFA Token
                  </label>
                  <input 
                    type="password"
                    placeholder="Enter password..."
                    value={fakeInput.password}
                    onChange={(e) => setFakeInput({ ...fakeInput, password: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setShowLandingPageModal(false)}
                    className="flex-1 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
                  >
                    Cancel / Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                  >
                    Sign In (Simulate Test)
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* POPUP 2: "Teach-In-The-Moment" Remediation Landing (KnowBe4 style instant coaching) */}
      {showTeachMomentModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="bg-rose-950/60 p-6 border-b border-rose-800/40 text-center">
              <div className="w-14 h-14 bg-rose-600/20 text-rose-400 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-rose-500/30">
                <AlertTriangle className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Oops! You fell for a simulated test.
              </h2>
              <p className="text-xs text-rose-300/90 mt-1 max-w-sm mx-auto">
                Don’t worry—this was an authorized test conducted by the Acme Security Team. No real data was exposed!
              </p>
            </div>

            <div className="p-6 space-y-4">
              <div className="text-xs font-semibold text-slate-300">
                Here are the warning signs you missed in this email:
              </div>

              <div className="space-y-2.5">
                {currentTemplate.redFlags.slice(0, 3).map((flag) => (
                  <div key={flag.id} className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-1">
                      <span>•</span>
                      <span>{flag.title}</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {flag.description}
                    </p>
                  </div>
                ))}
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => setShowTeachMomentModal(false)}
                  className="flex-1 py-2.5 px-4 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-750 rounded-lg transition-colors"
                >
                  I Understand, Return to Lab
                </button>
                <button
                  onClick={() => {
                    setShowTeachMomentModal(false);
                    onStartCourse(mapVectorToCourseSlug(currentTemplate.attackVector));
                  }}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Start 3-Min Refresher</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* POPUP 3: Successful Phishing Report Modal (PhishAlarm reward) */}
      {showReportSuccessModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="bg-emerald-950/60 p-6 border-b border-emerald-800/40 text-center">
              <div className="w-14 h-14 bg-emerald-600/20 text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-emerald-500/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Outstanding Catch!
              </h2>
              <p className="text-xs text-emerald-300/90 mt-1">
                You successfully detected and reported this simulated phishing email.
              </p>
            </div>

            <div className="p-6 space-y-4 text-center">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400 mb-1">Defense Impact:</div>
                <div className="text-sm font-bold text-white">
                  Email Quarantined · Phish-Prone Score Improved
                </div>
                <div className="mt-3 flex items-center justify-center gap-4 text-xs">
                  <span className="font-mono text-emerald-400 font-bold tabular-nums">+50 XP</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-300">Phish Hunter Rank #1</span>
                </div>
              </div>

              <p className="text-xs text-slate-400">
                By reporting quickly, you protected other employees across the organization from potential credential theft.
              </p>

              <button
                onClick={() => setShowReportSuccessModal(false)}
                className="w-full py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
              >
                Continue Training
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
