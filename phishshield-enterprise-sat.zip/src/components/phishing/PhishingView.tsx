import React, { useState } from 'react';
import { 
  PhishingCampaign, 
  PhishingTemplate, 
  AttackVector 
} from '../../types';
import { 
  MailWarning, 
  Plus, 
  Search, 
  Play, 
  Pause, 
  CheckCircle, 
  Clock, 
  BarChart3, 
  Flame, 
  ExternalLink, 
  Send, 
  Filter,
  ShieldAlert,
  ChevronRight,
  TrendingDown
} from 'lucide-react';

interface PhishingViewProps {
  campaigns: PhishingCampaign[];
  templates: PhishingTemplate[];
  onOpenThreatLab: (templateId: string) => void;
  onCreateCampaign: (campaign: PhishingCampaign) => void;
}

export const PhishingView: React.FC<PhishingViewProps> = ({
  campaigns,
  templates,
  onOpenThreatLab,
  onCreateCampaign
}) => {
  const [activeTab, setActiveTab] = useState<'campaigns' | 'templates'>('campaigns');
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [vectorFilter, setVectorFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Form state for creating new campaign
  const [newCampaignName, setNewCampaignName] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState(templates[0]?.id || '');
  const [targetDepartment, setTargetDepartment] = useState('All Organization');
  const [sendSchedule, setSendSchedule] = useState('Immediate (Simulated Blast)');

  const filteredTemplates = templates.filter(tmpl => {
    const matchesVector = vectorFilter === 'All' || tmpl.attackVector === vectorFilter;
    const matchesSearch = tmpl.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tmpl.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesVector && matchesSearch;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const template = templates.find(t => t.id === selectedTemplateId) || templates[0];
    const newCamp: PhishingCampaign = {
      id: `camp-${Date.now()}`,
      name: newCampaignName || `Simulation: ${template.name}`,
      targetDepartment,
      templateId: template.id,
      templateName: template.name,
      attackVector: template.attackVector,
      status: 'Active',
      scheduledDate: new Date().toISOString().split('T')[0],
      totalSent: targetDepartment === 'All Organization' ? 1420 : 68,
      openedCount: 0,
      clickedCount: 0,
      reportedCount: 0,
      compromisedCount: 0
    };
    onCreateCampaign(newCamp);
    setShowCreateModal(false);
    setNewCampaignName('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Zone */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Phishing Simulation Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Schedule automated baseline simulations, measure Phish-Prone Percentage (PPP), and train repeat clickers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Segmented Tab Filter */}
          <div className="flex items-center bg-slate-900 border border-slate-800 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('campaigns')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'campaigns'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sim Campaigns ({campaigns.length})
            </button>
            <button
              onClick={() => setActiveTab('templates')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'templates'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Threat Templates ({templates.length})
            </button>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Campaign</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Campaigns Overview */}
      {activeTab === 'campaigns' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Total Simulations Sent</div>
              <div className="text-xl font-bold text-white font-mono tabular-nums">
                {campaigns.reduce((sum, c) => sum + c.totalSent, 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Across 6 departments</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Avg Phish-Prone Click Rate</div>
              <div className="text-xl font-bold text-amber-400 font-mono tabular-nums">
                {(
                  (campaigns.reduce((sum, c) => sum + c.clickedCount, 0) /
                   Math.max(1, campaigns.reduce((sum, c) => sum + c.totalSent, 0))) * 100
                ).toFixed(1)}%
              </div>
              <div className="text-[11px] text-emerald-400 mt-1">▼ Down from 34.2% baseline</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">PhishShield Reporting Rate</div>
              <div className="text-xl font-bold text-blue-400 font-mono tabular-nums">
                {(
                  (campaigns.reduce((sum, c) => sum + c.reportedCount, 0) /
                   Math.max(1, campaigns.reduce((sum, c) => sum + c.totalSent, 0))) * 100
                ).toFixed(1)}%
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Reported via 1-click button</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Credential Compromises</div>
              <div className="text-xl font-bold text-rose-400 font-mono tabular-nums">
                {campaigns.reduce((sum, c) => sum + c.compromisedCount, 0)}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">Enrolled in remedial training</div>
            </div>
          </div>

          {/* Campaigns Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Active & Completed Campaigns
              </span>
              <span className="text-xs text-slate-500 font-mono">
                Real-time funnel metrics
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium">
                    <th className="py-3 px-4">Campaign Name</th>
                    <th className="py-3 px-4">Attack Vector</th>
                    <th className="py-3 px-4">Audience</th>
                    <th className="py-3 px-4 text-right">Sent</th>
                    <th className="py-3 px-4 text-right">Clicked (PPP)</th>
                    <th className="py-3 px-4 text-right">Reported</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {campaigns.map((camp) => {
                    const clickRate = camp.totalSent > 0 ? ((camp.clickedCount / camp.totalSent) * 100).toFixed(1) : '0.0';
                    const reportRate = camp.totalSent > 0 ? ((camp.reportedCount / camp.totalSent) * 100).toFixed(1) : '0.0';

                    return (
                      <tr key={camp.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3.5 px-4 font-semibold text-white">
                          <div>{camp.name}</div>
                          <div className="text-[11px] text-slate-500 font-normal mt-0.5">
                            Template: {camp.templateName}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="text-slate-300">{camp.attackVector}</span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-400">
                          {camp.targetDepartment}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                          {camp.totalSent.toLocaleString()}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                          <span className={Number(clickRate) > 15 ? 'text-rose-400 font-bold' : 'text-amber-400'}>
                            {camp.clickedCount} ({clickRate}%)
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono tabular-nums text-blue-400">
                          {camp.reportedCount} ({reportRate}%)
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase font-semibold ${
                            camp.status === 'Active' 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' 
                              : camp.status === 'Scheduled'
                              ? 'bg-blue-950 text-blue-400 border border-blue-800'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}>
                            {camp.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => onOpenThreatLab(camp.templateId)}
                            className="inline-flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-medium"
                          >
                            <span>Inspect</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Threat Template Library */}
      {activeTab === 'templates' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-slate-900 border border-slate-800 rounded-xl">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text"
                placeholder="Search templates or subjects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs text-slate-400 shrink-0">Vector:</span>
              <select
                value={vectorFilter}
                onChange={(e) => setVectorFilter(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
              >
                <option value="All">All Attack Vectors</option>
                <option value="Credential Harvesting">Credential Harvesting</option>
                <option value="Business Email Compromise (BEC)">Business Email Compromise</option>
                <option value="QR Code Quishing">QR Code Quishing</option>
                <option value="HR / Payroll Urgent Trap">HR / Payroll Urgent Trap</option>
                <option value="Supply Chain / Vendor Spoof">Supply Chain / Vendor</option>
              </select>
            </div>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTemplates.map((template) => (
              <div 
                key={template.id} 
                className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-xs font-mono text-blue-400 font-medium">
                      {template.attackVector}
                    </span>
                    <div className="flex text-amber-400 text-xs">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <span key={i} className={i < template.difficulty ? 'text-amber-400' : 'text-slate-700'}>
                          ★
                        </span>
                      ))}
                    </div>
                  </div>

                  <h3 className="text-sm font-bold text-white mb-2 line-clamp-1">
                    {template.name}
                  </h3>

                  <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80 mb-3 space-y-1">
                    <div className="text-[11px] text-slate-400 truncate">
                      <span className="text-slate-500">From:</span> {template.senderName} ({template.senderEmail})
                    </div>
                    <div className="text-[11px] text-slate-300 font-medium truncate">
                      <span className="text-slate-500">Subject:</span> {template.subject}
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                    {template.explanationSummary}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="text-[11px] text-slate-400">
                    Industry Click: <span className="font-mono text-rose-400 font-bold">{template.historicalClickRate}%</span>
                  </div>
                  <button
                    onClick={() => onOpenThreatLab(template.id)}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <span>ThreatLab Preview</span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Create New Campaign */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Send className="w-4 h-4 text-blue-400" />
                <span>Schedule New Phishing Simulation</span>
              </h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Campaign Title
                </label>
                <input 
                  type="text"
                  placeholder="e.g., Q3 Baseline Test: Executive Wire Fraud"
                  value={newCampaignName}
                  onChange={(e) => setNewCampaignName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Attack Template Selection
                </label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  {templates.map(tmpl => (
                    <option key={tmpl.id} value={tmpl.id}>
                      [{tmpl.attackVector}] {tmpl.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Target Department
                  </label>
                  <select
                    value={targetDepartment}
                    onChange={(e) => setTargetDepartment(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="All Organization">All Organization (1,420)</option>
                    <option value="Finance & Accounting">Finance & Accounting (68)</option>
                    <option value="Engineering">Engineering (340)</option>
                    <option value="Sales & Marketing">Sales & Marketing (210)</option>
                    <option value="Human Resources">Human Resources (32)</option>
                    <option value="Customer Support">Customer Support (120)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Dispatch Cadence
                  </label>
                  <select
                    value={sendSchedule}
                    onChange={(e) => setSendSchedule(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="Immediate (Simulated Blast)">Immediate Dispatch</option>
                    <option value="Random Spread over 5 Days">Spread over 5 Days</option>
                    <option value="Scheduled for Next Monday">Scheduled Next Week</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-blue-950/40 border border-blue-800/40 rounded-lg text-[11px] text-blue-300 leading-relaxed">
                <strong>Automated Remediation:</strong> Any employee who submits credentials or clicks suspicious attachments will automatically be enrolled in the matching 3-minute remedial microlearning course within 24 hours (SOC 2 CC6.3 Compliance Rule).
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
                >
                  Launch Campaign
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
