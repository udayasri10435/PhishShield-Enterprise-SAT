import React, { useState } from 'react';
import { 
  MicrolearningCourse, 
  ScenarioStep, 
  ScenarioChoice, 
  QuizQuestion 
} from '../../types';
import { 
  GraduationCap, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  ArrowRight, 
  Award, 
  RotateCcw, 
  BookOpen, 
  ShieldCheck, 
  Clock, 
  ChevronRight, 
  Sparkles,
  FileCheck
} from 'lucide-react';

interface MicrolearningViewProps {
  courses: MicrolearningCourse[];
  activeCourseSlug?: string;
  onSelectCourse: (slug: string) => void;
  onCompleteCourse: (courseId: string, score: number) => void;
}

export const MicrolearningView: React.FC<MicrolearningViewProps> = ({
  courses,
  activeCourseSlug,
  onSelectCourse,
  onCompleteCourse
}) => {
  const [selectedCourse, setSelectedCourse] = useState<MicrolearningCourse | null>(
    activeCourseSlug ? courses.find(c => c.slug === activeCourseSlug) || null : null
  );

  // Player state
  const [currentStage, setCurrentStage] = useState<'intro' | 'scenario' | 'quiz' | 'completed'>('intro');
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState<number>(0);
  const [chosenChoice, setChosenChoice] = useState<ScenarioChoice | null>(null);
  
  // Quiz state
  const [currentQuizIndex, setCurrentQuizIndex] = useState<number>(0);
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<{ [qIndex: number]: number }>({});
  const [isQuizSubmitted, setIsQuizSubmitted] = useState<boolean>(false);
  const [quizScore, setQuizScore] = useState<number>(0);

  const startCourse = (course: MicrolearningCourse) => {
    setSelectedCourse(course);
    setCurrentStage('scenario');
    setCurrentScenarioIndex(0);
    setChosenChoice(null);
    setCurrentQuizIndex(0);
    setSelectedQuizOption(null);
    setQuizAnswers({});
    setIsQuizSubmitted(false);
  };

  const handleSelectChoice = (choice: ScenarioChoice) => {
    setChosenChoice(choice);
  };

  const handleNextScenario = () => {
    if (!selectedCourse) return;
    if (currentScenarioIndex < selectedCourse.scenarioSteps.length - 1) {
      setCurrentScenarioIndex(currentScenarioIndex + 1);
      setChosenChoice(null);
    } else {
      // Move to quiz
      setCurrentStage('quiz');
      setCurrentQuizIndex(0);
      setSelectedQuizOption(null);
    }
  };

  const handleSelectQuizOption = (optionIndex: number) => {
    if (isQuizSubmitted) return;
    setSelectedQuizOption(optionIndex);
    setQuizAnswers(prev => ({ ...prev, [currentQuizIndex]: optionIndex }));
  };

  const handleNextQuizQuestion = () => {
    if (!selectedCourse) return;
    if (currentQuizIndex < selectedCourse.quizQuestions.length - 1) {
      setCurrentQuizIndex(currentQuizIndex + 1);
      setSelectedQuizOption(quizAnswers[currentQuizIndex + 1] ?? null);
    } else {
      // Calculate score
      let correct = 0;
      selectedCourse.quizQuestions.forEach((q, idx) => {
        if (quizAnswers[idx] === q.correctIndex) {
          correct++;
        }
      });
      const finalScorePercent = Math.round((correct / selectedCourse.quizQuestions.length) * 100);
      setQuizScore(finalScorePercent);
      setIsQuizSubmitted(true);
      setCurrentStage('completed');
      onCompleteCourse(selectedCourse.id, finalScorePercent);
    }
  };

  return (
    <div className="space-y-6">
      {/* If no course is currently actively being taken in the player, show the Course Catalog */}
      {!selectedCourse || currentStage === 'intro' ? (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">
                Adaptive Microlearning Library
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Bite-sized 3-to-5 minute interactive threat scenarios mapped directly to SOC 2, ISO 27001, and HIPAA controls.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="font-mono text-emerald-400 font-bold tabular-nums">100%</span>
              <span>Audit Trackable</span>
            </div>
          </div>

          {/* Course Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {courses.map((course) => (
              <div 
                key={course.id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <span className="text-[11px] font-semibold text-blue-400">
                      {course.category}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{course.durationMinutes} min</span>
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white mb-2 line-clamp-1">
                    {course.title}
                  </h3>

                  <p className="text-xs text-slate-400 mb-4 line-clamp-3 leading-relaxed">
                    {course.summary}
                  </p>

                  {/* Compliance framework tags */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {course.complianceFrameworks.map(fw => (
                      <span key={fw} className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {fw}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500">
                    Reward: <span className="text-slate-300 font-medium">{course.badgeReward.title}</span>
                  </div>
                  <button
                    onClick={() => startCourse(course)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                  >
                    <span>Launch Scenario</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Interactive Course Player Canvas */
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Top Progress & Navigation Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setSelectedCourse(null);
                  setCurrentStage('intro');
                }}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                ← Back to Courses
              </button>
              <span className="text-slate-700">|</span>
              <span className="text-xs font-bold text-white">
                {selectedCourse.title}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">
                {currentStage === 'scenario' && `Scenario Step ${currentScenarioIndex + 1}/${selectedCourse.scenarioSteps.length}`}
                {currentStage === 'quiz' && `Knowledge Check ${currentQuizIndex + 1}/${selectedCourse.quizQuestions.length}`}
                {currentStage === 'completed' && 'Module Completed'}
              </span>
            </div>
          </div>

          {/* STAGE 1: Interactive Scenario with Branching Choices */}
          {currentStage === 'scenario' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl animate-in fade-in">
              {/* Situation Header */}
              <div className="bg-slate-950 p-6 border-b border-slate-800">
                <div className="text-[11px] font-mono text-amber-400 uppercase tracking-wider mb-1 font-semibold">
                  {selectedCourse.scenarioSteps[currentScenarioIndex].contextKicker}
                </div>
                <h2 className="text-base font-bold text-white leading-relaxed">
                  {selectedCourse.scenarioSteps[currentScenarioIndex].situation}
                </h2>
              </div>

              {/* Decision Choices */}
              <div className="p-6 space-y-3">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  What is your recommended course of action?
                </div>

                {selectedCourse.scenarioSteps[currentScenarioIndex].choices.map((choice) => (
                  <button
                    key={choice.id}
                    onClick={() => handleSelectChoice(choice)}
                    className={`w-full text-left p-4 rounded-xl border transition-all text-xs ${
                      chosenChoice?.id === choice.id
                        ? choice.isCorrect
                          ? 'bg-emerald-950/40 border-emerald-500/70 text-emerald-200'
                          : 'bg-rose-950/40 border-rose-500/70 text-rose-200'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-medium text-sm leading-snug">
                      {choice.text}
                    </div>

                    {/* Reveal feedback if chosen */}
                    {chosenChoice?.id === choice.id && (
                      <div className="mt-3 pt-3 border-t border-slate-800 space-y-1.5 animate-in fade-in">
                        <div className="flex items-center gap-1.5 font-bold">
                          {choice.isCorrect ? (
                            <span className="text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 className="w-4 h-4" /> Correct Defensive Action!
                            </span>
                          ) : (
                            <span className="text-rose-400 flex items-center gap-1">
                              <AlertCircle className="w-4 h-4" /> Vulnerable Choice
                            </span>
                          )}
                        </div>
                        <p className="text-slate-300 text-xs leading-relaxed">
                          {choice.feedback}
                        </p>
                        <div className="text-[11px] font-mono text-slate-400">
                          Risk Impact: {choice.riskImpact}
                        </div>
                      </div>
                    )}
                  </button>
                ))}
              </div>

              {/* Footer advance button */}
              <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Select the choice to evaluate defensive outcome
                </span>
                <button
                  disabled={!chosenChoice}
                  onClick={handleNextScenario}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                    chosenChoice
                      ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <span>
                    {currentScenarioIndex < selectedCourse.scenarioSteps.length - 1
                      ? 'Next Decision'
                      : 'Proceed to Knowledge Quiz'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STAGE 2: End-of-Module Knowledge Check Quiz */}
          {currentStage === 'quiz' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl animate-in fade-in">
              <div className="bg-slate-950 p-6 border-b border-slate-800">
                <div className="text-xs font-mono text-blue-400 uppercase tracking-wider mb-1">
                  Knowledge Evaluation · Question {currentQuizIndex + 1} of {selectedCourse.quizQuestions.length}
                </div>
                <h2 className="text-base font-bold text-white">
                  {selectedCourse.quizQuestions[currentQuizIndex].question}
                </h2>
              </div>

              <div className="p-6 space-y-3">
                {selectedCourse.quizQuestions[currentQuizIndex].options.map((opt, oIdx) => (
                  <button
                    key={oIdx}
                    onClick={() => handleSelectQuizOption(oIdx)}
                    className={`w-full text-left p-4 rounded-xl border text-xs transition-all ${
                      selectedQuizOption === oIdx
                        ? 'bg-blue-950/60 border-blue-500 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] font-mono font-bold shrink-0 ${
                        selectedQuizOption === oIdx
                          ? 'border-blue-400 bg-blue-500 text-white'
                          : 'border-slate-700 text-slate-400'
                      }`}>
                        {String.fromCharCode(65 + oIdx)}
                      </div>
                      <span className="font-medium text-xs leading-normal">{opt}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Passing score requires 80% or higher for compliance accreditation
                </span>
                <button
                  disabled={selectedQuizOption === null}
                  onClick={handleNextQuizQuestion}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                    selectedQuizOption !== null
                      ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <span>
                    {currentQuizIndex < selectedCourse.quizQuestions.length - 1
                      ? 'Next Question'
                      : 'Submit & View Results'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STAGE 3: Completion Certificate & Badge Unlock */}
          {currentStage === 'completed' && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl p-8 text-center space-y-6 animate-in zoom-in-95">
              <div className="w-16 h-16 bg-emerald-600/20 text-emerald-400 rounded-2xl flex items-center justify-center mx-auto border border-emerald-500/30">
                <Award className="w-9 h-9" />
              </div>

              <div>
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest font-semibold">
                  Accreditation Satisfied
                </span>
                <h2 className="text-xl font-bold text-white mt-1">
                  Congratulations! Course Completed
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  You scored <strong className="text-emerald-400 font-mono text-sm">{quizScore}%</strong> on the evaluation. Your training record has been synchronized with the SOC 2 compliance auditor logs.
                </p>
              </div>

              {/* Certificate Snapshot Card */}
              <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 text-left space-y-3 max-w-md mx-auto">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-[11px] font-mono text-slate-500">CERTIFICATE ID: #SAT-{selectedCourse.id.toUpperCase()}-2026</span>
                  <span className="text-[11px] text-emerald-400 font-medium">VERIFIED</span>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Awarded to:</div>
                  <div className="text-sm font-bold text-white">Alex Chen (Finance & Operations)</div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Curriculum:</div>
                  <div className="text-xs font-semibold text-slate-200">{selectedCourse.title}</div>
                </div>
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>Issued: Today</span>
                  <span>Expires: 12 Months</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => {
                    setSelectedCourse(null);
                    setCurrentStage('intro');
                  }}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                >
                  Return to Microlearning Catalog
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
