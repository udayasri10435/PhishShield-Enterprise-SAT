import React, { useState } from 'react';
import { 
  ComplianceFramework, 
  EmployeeRecord 
} from '../../types';
import { 
  FileCheck2, 
  Download, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ShieldCheck, 
  Send, 
  ChevronRight, 
  FileText,
  Printer,
  Sparkles,
  ExternalLink,
  Users
} from 'lucide-react';

interface ComplianceViewProps {
  frameworks: ComplianceFramework[];
  employees: EmployeeRecord[];
  onNudgeEmployees: (employeeIds: string[]) => void;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({
  frameworks,
  employees,
  onNudgeEmployees
}) => {
  const [selectedFrameworkId, setSelectedFrameworkId] = useState<string>(frameworks[0]?.id || '');
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [nudgeSentToast, setNudgeSentToast] = useState<boolean>(false);

  const currentFramework = frameworks.find(f => f.id === selectedFrameworkId) || frameworks[0];
  const overdueEmployees = employees.filter(e => e.complianceStatus === 'Overdue' || e.complianceStatus === 'In Progress');

  const handleBatchNudge = () => {
    onNudgeEmployees(overdueEmployees.map(e => e.id));
    setNudgeSentToast(true);
    setTimeout(() => setNudgeSentToast(false), 4000);
  };

  const handleDownloadCsv = () => {
    const csvHeader = "Framework,Control Code,Title,Status,Compliance Rate,Evidence Records,Last Audit\n";
    const csvRows = frameworks.flatMap(fw => 
      fw.controls.map(c => 
        `"${fw.name}","${c.code}","${c.title}","${c.status}","${c.complianceRate}%","${c.evidenceCount}","${c.lastAuditDate}"`
      )
    ).join("\n");

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SAT_Compliance_Audit_Export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Compliance Reporting & Audit Readiness
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Automated evidence collection, auditor verification packages, and workforce compliance tracking.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowExportModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Export Auditor Package</span>
          </button>
        </div>
      </div>

      {/* Framework Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {frameworks.map((fw) => (
          <div
            key={fw.id}
            onClick={() => setSelectedFrameworkId(fw.id)}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              selectedFrameworkId === fw.id
                ? 'bg-slate-900 border-blue-500/60 ring-1 ring-blue-500/30'
                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-white">{fw.name}</span>
              <span className="font-mono text-xs font-bold text-emerald-400 tabular-nums">
                {fw.readinessPercentage}%
              </span>
            </div>

            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
              <div 
                className="bg-emerald-500 h-full rounded-full transition-all"
                style={{ width: `${fw.readinessPercentage}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>{fw.satisfiedControls} of {fw.totalControls} Controls Ready</span>
              <span className="text-slate-400 font-mono">{fw.standardCode.split('/')[0]}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Framework Control Checklist */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="text-xs font-mono text-blue-400 font-semibold uppercase tracking-wider">
              {currentFramework.standardCode}
            </div>
            <h2 className="text-base font-bold text-white mt-0.5">
              {currentFramework.name} — Control Breakdown & Evidence Logs
            </h2>
          </div>
          <div className="text-xs text-slate-400 max-w-sm">
            {currentFramework.auditorDescription}
          </div>
        </div>

        <div className="divide-y divide-slate-800/80">
          {currentFramework.controls.map((ctrl) => (
            <div key={ctrl.code} className="p-5 hover:bg-slate-850/40 transition-colors">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-1.5 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-blue-400 bg-blue-950/80 border border-blue-800/60 px-2 py-0.5 rounded">
                      {ctrl.code}
                    </span>
                    <h3 className="text-sm font-bold text-white">{ctrl.title}</h3>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {ctrl.description}
                  </p>
                  {ctrl.gapNotes && (
                    <div className="p-2.5 rounded bg-amber-950/40 border border-amber-800/40 text-[11px] text-amber-300 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                      <span>{ctrl.gapNotes}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-6 shrink-0 text-xs">
                  <div className="text-right">
                    <div className="text-[11px] text-slate-500">Compliance Rate</div>
                    <div className="font-mono text-sm font-bold text-white tabular-nums">
                      {ctrl.complianceRate}%
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[11px] text-slate-500">Evidence Vault</div>
                    <div className="font-mono text-sm font-bold text-blue-400 tabular-nums">
                      {ctrl.evidenceCount} records
                    </div>
                  </div>

                  <div>
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium font-mono uppercase ${
                      ctrl.status === 'Satisfied'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : ctrl.status === 'In Progress'
                        ? 'bg-blue-950 text-blue-400 border border-blue-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {ctrl.status === 'Satisfied' && <CheckCircle2 className="w-3 h-3" />}
                      {ctrl.status === 'Action Required' && <AlertTriangle className="w-3 h-3" />}
                      <span>{ctrl.status}</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Non-Compliant Escalation & Nudge List */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white">
              Workforce Remediation & Overdue Training ({overdueEmployees.length} Personnel)
            </h2>
          </div>

          <button
            onClick={handleBatchNudge}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Batch Slack / Email Nudge</span>
          </button>
        </div>

        {nudgeSentToast && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs rounded-lg flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Automated Slack DM & calendar reminders dispatched to {overdueEmployees.length} non-compliant employees!</span>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium bg-slate-950/40">
                <th className="py-2.5 px-3">Employee</th>
                <th className="py-2.5 px-3">Department</th>
                <th className="py-2.5 px-3 text-right">Phish-Prone %</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Overdue Module</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {overdueEmployees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-850/40">
                  <td className="py-2.5 px-3 font-medium text-white">
                    {emp.name} ({emp.email})
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">{emp.department}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-400 tabular-nums">
                    {emp.phishProneScore}%
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">
                      {emp.complianceStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                    Defeating BEC & CEO Wire Fraud (Remedial)
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: Auditor Evidence Export */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-lg w-full overflow-hidden shadow-2xl animate-in zoom-in-95">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-blue-400" />
                <span>Export Official Compliance Audit Packet</span>
              </h2>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-300">
              <p>
                This packet packages all phishing simulation logs, timestamped microlearning quiz completions, and remediated non-compliance trails for external certified auditors (PwC, EY, Deloitte, Coalfire).
              </p>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-slate-400">
                  <span>Scope:</span>
                  <span className="text-white font-medium">Acme Enterprise Global (1,420 Users)</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Audit Frameworks:</span>
                  <span className="text-white font-medium">SOC 2 Type II, ISO 27001, HIPAA</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Evidence Records:</span>
                  <span className="font-mono text-emerald-400 font-bold tabular-nums">4,380 Verified Events</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Organization PPP™:</span>
                  <span className="font-mono text-emerald-400 font-bold tabular-nums">3.2% (Benchmark Pass)</span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  onClick={() => setShowExportModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 rounded-lg transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    handleDownloadCsv();
                    setShowExportModal(false);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Auditor CSV</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
