import React from 'react';
import { 
  PhishingCampaign, 
  SimulationEvent 
} from '../../types';
import { 
  ShieldAlert, 
  TrendingDown, 
  CheckCircle2, 
  Users2, 
  MailWarning, 
  Clock, 
  FileCheck2, 
  ChevronRight, 
  ArrowUpRight, 
  Send, 
  ScanSearch, 
  ExternalLink,
  Flame,
  AlertTriangle
} from 'lucide-react';
import { DEPARTMENT_STATS } from '../../data/mockData';

interface DashboardViewProps {
  campaigns: PhishingCampaign[];
  events: SimulationEvent[];
  onNavigateTab: (tab: string) => void;
  onOpenThreatLab: (templateId?: string) => void;
  onQuickSimulate: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  campaigns,
  events,
  onNavigateTab,
  onOpenThreatLab,
  onQuickSimulate
}) => {
  const activeCampaigns = campaigns.filter(c => c.status === 'Active');
  const totalSent = campaigns.reduce((acc, c) => acc + c.totalSent, 0);
  const totalReported = campaigns.reduce((acc, c) => acc + c.reportedCount, 0);
  const totalClicked = campaigns.reduce((acc, c) => acc + c.clickedCount, 0);

  const currentOrgPPP = totalSent > 0 ? ((totalClicked / totalSent) * 100).toFixed(1) : '3.2';
  const reportRate = totalSent > 0 ? ((totalReported / totalSent) * 100).toFixed(1) : '72.4';

  return (
    <div className="space-y-6">
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Enterprise Security Posture · Continuous Telemetry</span>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Security Awareness & Phishing Risk Center
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Simulating sophisticated cyber threats, automating remedial microlearning, and compiling verifiable evidence for SOC 2, ISO 27001, and HIPAA compliance.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigateTab('threatlab')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <ScanSearch className="w-3.5 h-3.5 text-amber-400" />
            <span>ThreatLab Inspector</span>
          </button>

          <button
            onClick={onQuickSimulate}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Launch Simulation</span>
          </button>
        </div>
      </div>

      {/* Hero Benchmark: Phish-Prone Percentage (PPP) Evolution */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-400">
              Key Metric · KnowBe4 / Proofpoint Benchmark
            </div>
            <h2 className="text-lg font-bold text-white mt-0.5">
              Organization Phish-Prone Percentage™ (PPP)
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-emerald-400 font-mono font-bold">-90.6% Drop</span>
            <span className="text-slate-400">over 90 days of microlearning</span>
          </div>
        </div>

        {/* 3-Stage Benchmark Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          {/* Baseline */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80">
            <div className="text-[11px] text-slate-500 mb-1">1. Initial Baseline (Day 0)</div>
            <div className="text-2xl font-bold font-mono text-slate-400 tabular-nums">
              34.2%
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Pre-training unannounced test</div>
          </div>

          {/* Industry Avg */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80">
            <div className="text-[11px] text-slate-500 mb-1">2. Industry Average (Tech/Finance)</div>
            <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              11.4%
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Global peer benchmark</div>
          </div>

          {/* Current Posture */}
          <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/50">
            <div className="text-[11px] text-emerald-400 font-semibold mb-1">3. Current Organization PPP</div>
            <div className="text-3xl font-extrabold font-mono text-emerald-400 tabular-nums">
              {currentOrgPPP}%
            </div>
            <div className="text-[11px] text-emerald-300/80 mt-1 font-medium">
              Top 2% Cyber Vigilance Tier
            </div>
          </div>
        </div>
      </div>

      {/* Secondary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>PhishShield Report Rate</span>
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {reportRate}%
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            ▲ +18.4% faster employee triage
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Active Phish Simulations</span>
            <MailWarning className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {activeCampaigns.length} Active
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            M365 Expiry & CEO Wire Fraud
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Training Compliance Rate</span>
            <FileCheck2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            91.8%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            1,304 of 1,420 users certified
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>High Risk Repeat Clickers</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums">
            8 Users
          </div>
          <div className="text-[11px] text-rose-300/80 mt-1">
            Remedial microlearning assigned
          </div>
        </div>
      </div>

      {/* Two Column Layout: Department Risk Heatmap & Live Telemetry Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Department Risk Matrix Heatmap */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Department Risk Matrix & Phish-Prone Scores
            </h3>
            <button
              onClick={() => onNavigateTab('employees')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
            >
              <span>View Directory</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium">
                  <th className="py-2.5 px-4">Department</th>
                  <th className="py-2.5 px-3 text-right">Headcount</th>
                  <th className="py-2.5 px-3 text-right">Phish-Prone %</th>
                  <th className="py-2.5 px-3 text-right">Training Done</th>
                  <th className="py-2.5 px-3 text-center">Risk Level</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {DEPARTMENT_STATS.map((dept) => (
                  <tr key={dept.name} className="hover:bg-slate-850/40">
                    <td className="py-3 px-4 font-semibold text-white">{dept.name}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-400">
                      {dept.size}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                      <span className={
                        dept.phishProneScore > 15 
                          ? 'text-rose-400' 
                          : dept.phishProneScore > 6 
                          ? 'text-amber-400' 
                          : 'text-emerald-400'
                      }>
                        {dept.phishProneScore}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-300">
                      {dept.trainingCompletion}%
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase ${
                        dept.riskLevel === 'Low'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : dept.riskLevel === 'Moderate'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}>
                        {dept.riskLevel}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Real-time Incident & Simulation Event Stream */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
              <span>Live Simulation Feed</span>
            </h3>
            <span className="text-[11px] font-mono text-slate-500">Real-time</span>
          </div>

          <div className="divide-y divide-slate-800/80 p-2 max-h-[380px] overflow-y-auto">
            {events.map((ev) => (
              <div key={ev.id} className="p-3 hover:bg-slate-850/60 rounded-lg transition-colors text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{ev.employeeName}</span>
                    <span className="text-slate-500">({ev.department})</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 tabular-nums">
                    {ev.timestamp}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold uppercase ${
                    ev.action === 'REPORTED'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : ev.action === 'COMPROMISED'
                      ? 'bg-rose-950 text-rose-400 border border-rose-800'
                      : ev.action === 'CLICKED'
                      ? 'bg-amber-950 text-amber-400 border border-amber-800'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}>
                    {ev.action}
                  </span>
                  <span className="text-[11px] text-slate-400 truncate">
                    {ev.campaignName}
                  </span>
                </div>

                <p className="text-[11px] text-slate-400 leading-normal">
                  {ev.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
