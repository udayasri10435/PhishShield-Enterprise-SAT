import React from 'react';
import { 
  ShieldCheck, 
  UserCheck, 
  Send, 
  Bell,
  Search,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  portalMode: 'admin' | 'learner';
  onTogglePortalMode: (mode: 'admin' | 'learner') => void;
  onQuickSimulate: () => void;
  lastSimEventText?: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  portalMode,
  onTogglePortalMode,
  onQuickSimulate,
  lastSimEventText
}) => {
  const getTabLabel = (tab: string) => {
    switch (tab) {
      case 'dashboard': return 'Executive Command Center';
      case 'phishing': return 'Phishing Simulation Suite';
      case 'threatlab': return 'ThreatLab™ Red Flag Inspector';
      case 'microlearning': return 'Adaptive Microlearning & Quizzes';
      case 'compliance': return 'Compliance Reporting & Audit Center';
      case 'employees': return 'Workforce Risk Directory';
      case 'learner': return 'Employee Security Training Portal';
      default: return 'Security Operations';
    }
  };

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between">
      {/* Zone 1: Brand title & Context */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
              PhishShield <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-blue-950/80 text-blue-400 border border-blue-800/60">SAT</span>
            </span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-2 text-xs text-slate-500 pl-4 border-l border-slate-800">
          <span>Enterprise Security</span>
          <span aria-hidden="true">/</span>
          <span className="text-slate-300 font-medium">{getTabLabel(currentTab)}</span>
        </div>
      </div>

      {/* Zone 2: Telemetry notification ticker */}
      <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 max-w-md truncate">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
        <span className="truncate">
          {lastSimEventText || 'Telemetry Active · All simulation mail gateways operational (0 errors)'}
        </span>
      </div>

      {/* Zone 3: Actions & Mode Switcher */}
      <div className="flex items-center gap-3">
        {/* Toggle between Admin Console and Learner Portal */}
        <div className="flex items-center bg-slate-900 border border-slate-800 p-0.5 rounded-lg">
          <button
            onClick={() => onTogglePortalMode('admin')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
              portalMode === 'admin' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Admin Console</span>
          </button>
          <button
            onClick={() => onTogglePortalMode('learner')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
              portalMode === 'learner' 
                ? 'bg-indigo-600 text-white shadow-sm' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Learner View</span>
          </button>
        </div>

        {portalMode === 'admin' && (
          <button
            onClick={onQuickSimulate}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap"
          >
            <Send className="w-3.5 h-3.5 text-blue-400" />
            <span>Launch Quick Test</span>
          </button>
        )}

        {/* User profile capsule */}
        <div className="flex items-center gap-2.5 pl-3 border-l border-slate-800">
          <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-700 to-indigo-500 flex items-center justify-center text-xs font-semibold text-white">
            {portalMode === 'admin' ? 'SC' : 'AC'}
          </div>
          <div className="hidden xl:block text-left">
            <div className="text-xs font-medium text-slate-200 leading-none">
              {portalMode === 'admin' ? 'SecOps Team' : 'Alex Chen'}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              {portalMode === 'admin' ? 'CISO Admin' : 'Finance Analyst'}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
