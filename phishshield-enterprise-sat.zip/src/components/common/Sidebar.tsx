import React from 'react';
import { 
  LayoutDashboard, 
  MailWarning, 
  ScanSearch, 
  GraduationCap, 
  FileCheck2, 
  Users2, 
  Flame,
  Award,
  BookOpenCheck,
  ShieldCheck
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  portalMode: 'admin' | 'learner';
  activeCampaignCount: number;
  openCourseCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  portalMode,
  activeCampaignCount,
  openCourseCount
}) => {
  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-950 flex flex-col shrink-0 select-none">
      {/* Platform Sub-header or Role status */}
      <div className="p-4 border-b border-slate-900">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">
            {portalMode === 'admin' ? 'Organization Scope' : 'Employee Workspace'}
          </span>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
            {portalMode === 'admin' ? 'SOC 2 Active' : 'Level 4 Defender'}
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-300 font-semibold truncate">
          {portalMode === 'admin' ? 'Acme Enterprise Global (1,420 users)' : 'Alex Chen · Finance'}
        </div>
      </div>

      {/* Navigation Sections */}
      <div className="flex-1 py-4 px-3 space-y-6 overflow-y-auto">
        {portalMode === 'admin' ? (
          <div>
            <div className="px-3 mb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-500">
              Security Governance
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => onSelectTab('dashboard')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'dashboard'
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <LayoutDashboard className="w-4 h-4 shrink-0" />
                  <span>Command Center</span>
                </div>
              </button>

              <button
                onClick={() => onSelectTab('phishing')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'phishing'
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <MailWarning className="w-4 h-4 shrink-0" />
                  <span>Phishing Simulations</span>
                </div>
                {activeCampaignCount > 0 && (
                  <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 bg-blue-900/60 text-blue-300 rounded border border-blue-800">
                    {activeCampaignCount} Active
                  </span>
                )}
              </button>

              <button
                onClick={() => onSelectTab('threatlab')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'threatlab'
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/25'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ScanSearch className="w-4 h-4 shrink-0" />
                  <span>ThreatLab™ Inspector</span>
                </div>
                <span className="text-[10px] font-mono text-amber-400 font-semibold px-1 py-0.5 bg-amber-950/60 rounded border border-amber-800/60">
                  Interactive
                </span>
              </button>

              <button
                onClick={() => onSelectTab('microlearning')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'microlearning'
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <GraduationCap className="w-4 h-4 shrink-0" />
                  <span>Microlearning Courses</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {openCourseCount} modules
                </span>
              </button>
            </nav>

            <div className="px-3 mt-6 mb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-500">
              Audit & People
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => onSelectTab('compliance')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'compliance'
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileCheck2 className="w-4 h-4 shrink-0" />
                  <span>Compliance & Audits</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400">
                  96% Ready
                </span>
              </button>

              <button
                onClick={() => onSelectTab('employees')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'employees'
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Users2 className="w-4 h-4 shrink-0" />
                  <span>Employee Risk Directory</span>
                </div>
              </button>
            </nav>
          </div>
        ) : (
          <div>
            <div className="px-3 mb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-500">
              My Learning Path
            </div>
            <nav className="space-y-1">
              <button
                onClick={() => onSelectTab('learner')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'learner'
                    ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <BookOpenCheck className="w-4 h-4 shrink-0" />
                  <span>My Training & Scores</span>
                </div>
              </button>

              <button
                onClick={() => onSelectTab('threatlab')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'threatlab'
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/25'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ScanSearch className="w-4 h-4 shrink-0" />
                  <span>Phish Testing Sandbox</span>
                </div>
                <span className="text-[10px] font-mono text-amber-300">Practice</span>
              </button>

              <button
                onClick={() => onSelectTab('microlearning')}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors text-left ${
                  currentTab === 'microlearning'
                    ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <GraduationCap className="w-4 h-4 shrink-0" />
                  <span>All Microlearning Modules</span>
                </div>
              </button>
            </nav>
          </div>
        )}
      </div>

      {/* Bottom KPI Widget (KnowBe4 style Phish-Prone Metric) */}
      <div className="p-4 border-t border-slate-900 bg-slate-950/60">
        <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/40">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-slate-400">Org Phish-Prone %</span>
            <span className="font-mono font-bold text-emerald-400 tabular-nums">3.2%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: '91%' }} />
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Baseline: 34.2%</span>
            <span className="text-emerald-400 font-medium">-90.6% risk drop</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
