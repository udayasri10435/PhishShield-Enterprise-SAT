import React, { useState } from 'react';
import { EmployeeRecord } from '../../types';
import { 
  Users2, 
  Search, 
  Filter, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  Send,
  GraduationCap
} from 'lucide-react';

interface EmployeeDirectoryViewProps {
  employees: EmployeeRecord[];
  onAssignRemedial: (employeeId: string) => void;
}

export const EmployeeDirectoryView: React.FC<EmployeeDirectoryViewProps> = ({
  employees,
  onAssignRemedial
}) => {
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  const [assignedToast, setAssignedToast] = useState<string | null>(null);

  const departments = ['All', ...Array.from(new Set(employees.map(e => e.department)))];

  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = emp.name.toLowerCase().includes(search.toLowerCase()) || 
                          emp.email.toLowerCase().includes(search.toLowerCase()) ||
                          emp.role.toLowerCase().includes(search.toLowerCase());
    const matchesDept = departmentFilter === 'All' || emp.department === departmentFilter;
    const matchesRisk = riskFilter === 'All' || emp.riskTier === riskFilter;
    return matchesSearch && matchesDept && matchesRisk;
  });

  const handleAssign = (emp: EmployeeRecord) => {
    onAssignRemedial(emp.id);
    setAssignedToast(`Remedial microlearning assigned to ${emp.name}`);
    setTimeout(() => setAssignedToast(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight">
            Workforce Risk Directory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Individual Phish-Prone Percentages (PPP), simulation reporting habits, and compliance training progress.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs font-mono text-slate-400">
            Showing <strong className="text-white">{filteredEmployees.length}</strong> of {employees.length} users
          </div>
        </div>
      </div>

      {assignedToast && (
        <div className="p-3 bg-blue-950/80 border border-blue-800 text-blue-200 text-xs rounded-lg flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-blue-400" />
          <span>{assignedToast}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-slate-900 border border-slate-800 rounded-xl">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text"
            placeholder="Search by employee name, email, or role..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Dept:</span>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              {departments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Risk Tier:</span>
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="All">All Tiers</option>
              <option value="Low Risk">Low Risk (&lt;5%)</option>
              <option value="Moderate Risk">Moderate Risk (5-15%)</option>
              <option value="High Risk">High Risk (&gt;15%)</option>
            </select>
          </div>
        </div>
      </div>

      {/* High Density Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium">
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Department & Role</th>
                <th className="py-3 px-4 text-right">Phish-Prone %</th>
                <th className="py-3 px-4 text-center">Risk Tier</th>
                <th className="py-3 px-4 text-right">Sim History (Rep / Click)</th>
                <th className="py-3 px-4 text-center">Last Simulation</th>
                <th className="py-3 px-4 text-center">Training Progress</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {filteredEmployees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-850/50 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white">{emp.name}</div>
                    <div className="text-[11px] text-slate-500 font-mono">{emp.email}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="text-slate-200">{emp.department}</div>
                    <div className="text-[11px] text-slate-500">{emp.role}</div>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold tabular-nums">
                    <span className={
                      emp.phishProneScore > 15 
                        ? 'text-rose-400' 
                        : emp.phishProneScore > 5 
                        ? 'text-amber-400' 
                        : 'text-emerald-400'
                    }>
                      {emp.phishProneScore}%
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase font-semibold ${
                      emp.riskTier === 'High Risk'
                        ? 'bg-rose-950 text-rose-400 border border-rose-800'
                        : emp.riskTier === 'Moderate Risk'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}>
                      {emp.riskTier}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                    <span className="text-blue-400 font-medium">{emp.simulationsReported} Rep</span>
                    <span className="text-slate-600 mx-1">/</span>
                    <span className={emp.simulationsClicked > 2 ? 'text-rose-400 font-bold' : 'text-slate-400'}>
                      {emp.simulationsClicked} Click
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`text-[11px] font-medium ${
                      emp.lastSimulationOutcome === 'Reported' 
                        ? 'text-emerald-400' 
                        : emp.lastSimulationOutcome === 'Compromised' 
                        ? 'text-rose-400 font-bold' 
                        : 'text-amber-400'
                    }`}>
                      {emp.lastSimulationOutcome}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className="font-mono text-slate-200">
                      {emp.completedCoursesCount}/{emp.assignedCoursesCount}
                    </span>
                    <span className="text-[11px] text-slate-500 ml-1">
                      ({Math.round((emp.completedCoursesCount / emp.assignedCoursesCount) * 100)}%)
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleAssign(emp)}
                      className="px-2.5 py-1 text-[11px] font-medium text-blue-400 hover:text-blue-300 hover:bg-blue-950/40 border border-blue-800/60 rounded transition-colors inline-flex items-center gap-1"
                    >
                      <GraduationCap className="w-3 h-3" />
                      <span>Remediate</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
