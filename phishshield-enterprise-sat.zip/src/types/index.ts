export type AttackVector = 
  | 'Credential Harvesting'
  | 'Business Email Compromise (BEC)'
  | 'Ransomware / Malicious Attachment'
  | 'QR Code Quishing'
  | 'HR / Payroll Urgent Trap'
  | 'Supply Chain / Vendor Spoof';

export type DifficultyLevel = 1 | 2 | 3 | 4 | 5;

export interface RedFlag {
  id: string;
  location: 'sender' | 'replyTo' | 'subject' | 'body' | 'attachment' | 'link';
  title: string;
  description: string;
  severity: 'high' | 'critical' | 'medium';
}

export interface PhishingTemplate {
  id: string;
  name: string;
  attackVector: AttackVector;
  difficulty: DifficultyLevel;
  senderName: string;
  senderEmail: string;
  displayDomain: string;
  realDomain: string;
  replyTo?: string;
  subject: string;
  preheader: string;
  dateSent: string;
  hasAttachment?: boolean;
  attachmentName?: string;
  attachmentType?: string;
  simulatedLinkUrl: string;
  displayLinkText: string;
  htmlContent: string;
  redFlags: RedFlag[];
  landingPageType: 'microsoft_login' | 'docusign_portal' | 'payroll_direct_deposit' | 'it_ticket_portal' | 'qr_auth';
  explanationSummary: string;
  historicalClickRate: number; // e.g., 28.4%
}

export interface PhishingCampaign {
  id: string;
  name: string;
  targetDepartment: string; // 'All Organization' | 'Finance' | 'Engineering' etc.
  templateId: string;
  templateName: string;
  attackVector: AttackVector;
  status: 'Active' | 'Scheduled' | 'Completed' | 'Draft';
  scheduledDate: string;
  totalSent: number;
  openedCount: number;
  clickedCount: number;
  reportedCount: number;
  compromisedCount: number; // entered credentials
}

export interface ScenarioChoice {
  id: string;
  text: string;
  isCorrect: boolean;
  feedback: string;
  riskImpact: string;
}

export interface ScenarioStep {
  id: string;
  stepNumber: number;
  situation: string;
  contextKicker: string;
  senderContext?: string;
  emailExcerpt?: string;
  choices: ScenarioChoice[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface MicrolearningCourse {
  id: string;
  title: string;
  slug: string;
  durationMinutes: number;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  complianceFrameworks: string[]; // ['SOC 2 CC6.1', 'ISO 27001 A.6.3']
  summary: string;
  keyTakeaways: string[];
  scenarioSteps: ScenarioStep[];
  quizQuestions: QuizQuestion[];
  badgeReward: {
    title: string;
    description: string;
    iconName: string;
  };
}

export interface ComplianceControl {
  code: string;
  title: string;
  description: string;
  status: 'Satisfied' | 'Action Required' | 'In Progress';
  complianceRate: number; // 0 - 100
  evidenceCount: number;
  lastAuditDate: string;
  nextRenewalDate: string;
  gapNotes?: string;
}

export interface ComplianceFramework {
  id: string;
  name: string;
  standardCode: string;
  readinessPercentage: number;
  totalControls: number;
  satisfiedControls: number;
  auditorDescription: string;
  controls: ComplianceControl[];
}

export interface EmployeeRecord {
  id: string;
  name: string;
  email: string;
  department: string;
  role: string;
  phishProneScore: number; // e.g. 4.2%
  riskTier: 'Low Risk' | 'Moderate Risk' | 'High Risk';
  simulationsReceived: number;
  simulationsReported: number;
  simulationsClicked: number;
  simulationsCompromised: number;
  lastSimulationDate: string;
  lastSimulationOutcome: 'Reported' | 'Ignored' | 'Clicked' | 'Compromised';
  assignedCoursesCount: number;
  completedCoursesCount: number;
  complianceStatus: 'Compliant' | 'In Progress' | 'Overdue';
  lastActive: string;
}

export interface SimulationEvent {
  id: string;
  timestamp: string;
  employeeName: string;
  department: string;
  campaignName: string;
  action: 'REPORTED' | 'CLICKED' | 'COMPROMISED' | 'OPENED';
  detail: string;
}
