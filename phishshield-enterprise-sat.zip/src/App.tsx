/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  INITIAL_PHISHING_TEMPLATES,
  INITIAL_CAMPAIGNS,
  INITIAL_MICROLEARNING_COURSES,
  INITIAL_COMPLIANCE_FRAMEWORKS,
  INITIAL_EMPLOYEES,
  INITIAL_EVENTS
} from './data/mockData';
import { 
  PhishingTemplate, 
  PhishingCampaign, 
  MicrolearningCourse, 
  ComplianceFramework, 
  EmployeeRecord, 
  SimulationEvent 
} from './types';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { PhishingView } from './components/phishing/PhishingView';
import { ThreatLabInspector } from './components/phishing/ThreatLabInspector';
import { MicrolearningView } from './components/learning/MicrolearningView';
import { ComplianceView } from './components/compliance/ComplianceView';
import { EmployeeDirectoryView } from './components/employees/EmployeeDirectoryView';
import { LearnerPortalView } from './components/learner/LearnerPortalView';

export default function App() {
  // Navigation & Role states
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [portalMode, setPortalMode] = useState<'admin' | 'learner'>('admin');
  
  // Data stores
  const [templates, setTemplates] = useState<PhishingTemplate[]>(INITIAL_PHISHING_TEMPLATES);
  const [campaigns, setCampaigns] = useState<PhishingCampaign[]>(INITIAL_CAMPAIGNS);
  const [courses, setCourses] = useState<MicrolearningCourse[]>(INITIAL_MICROLEARNING_COURSES);
  const [frameworks, setFrameworks] = useState<ComplianceFramework[]>(INITIAL_COMPLIANCE_FRAMEWORKS);
  const [employees, setEmployees] = useState<EmployeeRecord[]>(INITIAL_EMPLOYEES);
  const [events, setEvents] = useState<SimulationEvent[]>(INITIAL_EVENTS);

  // Focus & Route targets
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(templates[0]?.id || '');
  const [activeCourseSlug, setActiveCourseSlug] = useState<string>('');

  // Log a simulation telemetry event and update real employee/campaign stats
  const handleRecordSimulationEvent = (action: 'REPORTED' | 'CLICKED' | 'COMPROMISED', detail: string) => {
    const newEvent: SimulationEvent = {
      id: `ev-${Date.now()}`,
      timestamp: 'Just now',
      employeeName: portalMode === 'learner' ? 'Alex Chen' : 'Simulated User',
      department: portalMode === 'learner' ? 'Finance & Accounting' : 'Operations',
      campaignName: templates.find(t => t.id === selectedTemplateId)?.name || 'Ad-Hoc Simulation',
      action,
      detail
    };

    setEvents(prev => [newEvent, ...prev.slice(0, 19)]);

    // Dynamically adjust Alex Chen's record if in Learner mode
    if (portalMode === 'learner') {
      setEmployees(prev => prev.map(emp => {
        if (emp.id === 'emp-001') {
          if (action === 'REPORTED') {
            return {
              ...emp,
              simulationsReported: emp.simulationsReported + 1,
              lastSimulationOutcome: 'Reported',
              phishProneScore: Math.max(0.5, Number((emp.phishProneScore - 0.3).toFixed(1)))
            };
          } else if (action === 'CLICKED') {
            return {
              ...emp,
              simulationsClicked: emp.simulationsClicked + 1,
              lastSimulationOutcome: 'Clicked',
              phishProneScore: Number((emp.phishProneScore + 1.2).toFixed(1))
            };
          } else if (action === 'COMPROMISED') {
            return {
              ...emp,
              simulationsCompromised: emp.simulationsCompromised + 1,
              lastSimulationOutcome: 'Compromised',
              phishProneScore: Number((emp.phishProneScore + 3.0).toFixed(1)),
              complianceStatus: 'In Progress'
            };
          }
        }
        return emp;
      }));
    }
  };

  const handleCreateCampaign = (newCamp: PhishingCampaign) => {
    setCampaigns(prev => [newCamp, ...prev]);
    // Dispatch telemetry
    const newEvent: SimulationEvent = {
      id: `ev-${Date.now()}`,
      timestamp: 'Just now',
      employeeName: 'SecOps Automation Engine',
      department: 'System',
      campaignName: newCamp.name,
      action: 'OPENED',
      detail: `Campaign initiated for ${newCamp.totalSent} users across ${newCamp.targetDepartment}`
    };
    setEvents(prev => [newEvent, ...prev]);
  };

  const handleStartCourse = (slug: string) => {
    setActiveCourseSlug(slug);
    setCurrentTab('microlearning');
  };

  const handleCompleteCourse = (courseId: string, score: number) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.id === 'emp-001') {
        const newCompleted = Math.min(emp.assignedCoursesCount, emp.completedCoursesCount + 1);
        return {
          ...emp,
          completedCoursesCount: newCompleted,
          complianceStatus: newCompleted >= emp.assignedCoursesCount ? 'Compliant' : 'In Progress'
        };
      }
      return emp;
    }));

    // Update compliance framework evidence record
    setFrameworks(prev => prev.map(fw => {
      return {
        ...fw,
        controls: fw.controls.map(c => ({
          ...c,
          evidenceCount: c.evidenceCount + 1
        }))
      };
    }));
  };

  const handleNudgeEmployees = (employeeIds: string[]) => {
    setEmployees(prev => prev.map(emp => {
      if (employeeIds.includes(emp.id)) {
        return { ...emp, complianceStatus: 'In Progress' };
      }
      return emp;
    }));
  };

  const handleAssignRemedial = (employeeId: string) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.id === employeeId) {
        return {
          ...emp,
          assignedCoursesCount: emp.assignedCoursesCount + 1,
          complianceStatus: 'In Progress'
        };
      }
      return emp;
    }));
  };

  const handleOpenThreatLab = (templateId?: string) => {
    if (templateId) {
      setSelectedTemplateId(templateId);
    }
    setCurrentTab('threatlab');
  };

  const handleTogglePortalMode = (mode: 'admin' | 'learner') => {
    setPortalMode(mode);
    if (mode === 'learner') {
      setCurrentTab('learner');
    } else {
      setCurrentTab('dashboard');
    }
  };

  const activeUser = employees.find(e => e.id === 'emp-001') || employees[0];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Header */}
      <Header
        currentTab={currentTab}
        portalMode={portalMode}
        onTogglePortalMode={handleTogglePortalMode}
        onQuickSimulate={() => handleOpenThreatLab()}
        lastSimEventText={events[0] ? `${events[0].employeeName} ${events[0].action.toLowerCase()} '${events[0].campaignName}' (${events[0].timestamp})` : undefined}
      />

      {/* Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={(tab) => {
            setCurrentTab(tab);
            if (tab !== 'microlearning') {
              setActiveCourseSlug('');
            }
          }}
          portalMode={portalMode}
          activeCampaignCount={campaigns.filter(c => c.status === 'Active').length}
          openCourseCount={courses.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8 bg-slate-950">
          <div className="max-w-7xl mx-auto">
            {currentTab === 'dashboard' && (
              <DashboardView
                campaigns={campaigns}
                events={events}
                onNavigateTab={(tab) => setCurrentTab(tab)}
                onOpenThreatLab={handleOpenThreatLab}
                onQuickSimulate={() => setCurrentTab('phishing')}
              />
            )}

            {currentTab === 'phishing' && (
              <PhishingView
                campaigns={campaigns}
                templates={templates}
                onOpenThreatLab={handleOpenThreatLab}
                onCreateCampaign={handleCreateCampaign}
              />
            )}

            {currentTab === 'threatlab' && (
              <ThreatLabInspector
                templates={templates}
                selectedTemplateId={selectedTemplateId}
                onSelectTemplate={(id) => setSelectedTemplateId(id)}
                onStartCourse={handleStartCourse}
                onRecordSimulationEvent={handleRecordSimulationEvent}
              />
            )}

            {currentTab === 'microlearning' && (
              <MicrolearningView
                courses={courses}
                activeCourseSlug={activeCourseSlug}
                onSelectCourse={(slug) => setActiveCourseSlug(slug)}
                onCompleteCourse={handleCompleteCourse}
              />
            )}

            {currentTab === 'compliance' && (
              <ComplianceView
                frameworks={frameworks}
                employees={employees}
                onNudgeEmployees={handleNudgeEmployees}
              />
            )}

            {currentTab === 'employees' && (
              <EmployeeDirectoryView
                employees={employees}
                onAssignRemedial={handleAssignRemedial}
              />
            )}

            {currentTab === 'learner' && (
              <LearnerPortalView
                currentUser={activeUser}
                courses={courses}
                onStartCourse={handleStartCourse}
                onOpenPracticeLab={() => handleOpenThreatLab()}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
